import csv
import json
import re
import string
import unicodedata
from functools import lru_cache
from io import BytesIO
from pathlib import Path
from urllib.parse import urlencode

from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.templatetags.static import static
from reportlab.lib import colors
from reportlab.lib.pagesizes import landscape, letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .ml import build_candidate_ml_insights
from .models import Candidate, ElectionResult
from .services import (
    ALL_FILTER,
    build_compare_dashboard,
    candidate_search_queryset,
    compute_barangay_dashboard,
    compute_candidate_dashboard,
    get_regions,
    resolve_location_filters,
)

HEADSHOT_DATA_FILE = Path(__file__).resolve().parent / "static" / "senators" / "data" / "candidate_headshots.json"
MAP_DATA_DIR = Path(__file__).resolve().parent / "static" / "senators" / "data" / "maps"
FAELDON_MAP_DIR = MAP_DATA_DIR / "faeldon"
STATIC_VERSION = "20260322-mapfix2"
REGION_CODE_LOOKUP = {
    "REGION I": "100000000",
    "REGION II": "200000000",
    "REGION III": "300000000",
    "REGION IV A": "400000000",
    "REGION V": "500000000",
    "REGION VI": "600000000",
    "REGION VII": "700000000",
    "REGION VIII": "800000000",
    "REGION IX": "900000000",
    "REGION X": "1000000000",
    "REGION XI": "1100000000",
    "REGION XII": "1200000000",
    "NATIONAL CAPITAL REGION": "1300000000",
    "CORDILLERA ADMINISTRATIVE REGION": "1400000000",
    "REGION XIII": "1600000000",
    "REGION IV B": "1700000000",
    "BARMM": "1900000000",
}
PROVINCE_NAME_ALIASES = {
    "NCR CITY OF MANILA FIRST DISTRICT NOT A PROVINCE": "NATIONAL CAPITAL REGION - MANILA",
    "NCR SECOND DISTRICT NOT A PROVINCE": "NATIONAL CAPITAL REGION - SECOND DISTRICT",
    "NCR THIRD DISTRICT NOT A PROVINCE": "NATIONAL CAPITAL REGION - THIRD DISTRICT",
    "NCR FOURTH DISTRICT NOT A PROVINCE": "NATIONAL CAPITAL REGION - FOURTH DISTRICT",
}


def _normalize_candidate_key(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").strip()).upper()


@lru_cache(maxsize=1)
def _load_candidate_headshots():
    if not HEADSHOT_DATA_FILE.exists():
        return {}
    raw = json.loads(HEADSHOT_DATA_FILE.read_text(encoding="utf-8"))
    return {_normalize_candidate_key(key): value for key, value in raw.items()}


def _candidate_headshot_url(candidate: Candidate) -> str:
    entry = _load_candidate_headshots().get(_normalize_candidate_key(candidate.full_name), {})
    return entry.get("url", "")


def _build_dataset_notes(regions):
    notes = []
    if len(regions) == 1:
        notes.append(f"Current dataset scope: {regions[0]} only.")
    if "NATIONAL CAPITAL REGION" in regions:
        notes.append("For NCR records, the source dataset uses Manila and district groupings in the Province field.")
    notes.append("The geographic heat maps use locally cached faeldon 2023 low-resolution Philippine GeoJSON files rendered as inline SVG choropleths where matching map boundaries are available.")
    return notes


def _dataset_banner():
    sources = list(
        ElectionResult.objects.exclude(source="")
        .order_by("source")
        .values_list("source", flat=True)
        .distinct()
    )
    if not sources:
        return None
    if len(sources) == 1:
        return {
            "label": "Active dataset",
            "name": sources[0],
            "detail": "Current database source",
        }
    return {
        "label": "Active datasets",
        "name": ", ".join(sources[:3]),
        "detail": f"{len(sources)} source files loaded",
    }


def _chart_colors():
    return {
        "primary": "#16324f",
        "accent": "#bd7b21",
        "soft": "#7999b9",
    }


def _notation_label(index: int) -> str:
    alphabet = string.ascii_uppercase
    label = ""
    current = index

    while True:
        current, remainder = divmod(current, 26)
        label = alphabet[remainder] + label
        if current == 0:
            return label
        current -= 1


def _notation_rows(rows):
    return [
        {
            **row,
            "notation": _notation_label(index),
        }
        for index, row in enumerate(rows)
    ]


def _single_series_chart(title, rows, value_key, color, label_key="name", full_label_key="name"):
    labels = [row[label_key] for row in rows]
    values = [row[value_key] for row in rows]
    return {
        "type": "bar",
        "data": {
            "labels": labels,
            "datasets": [
                {
                    "label": title,
                    "data": values,
                    "backgroundColor": color,
                    "borderRadius": 10,
                }
            ],
        },
        "meta": {
            "fullLabels": [row[full_label_key] for row in rows],
        },
        "options": {
            "responsive": True,
            "maintainAspectRatio": False,
            "plugins": {
                "legend": {"display": False},
            },
            "scales": {
                "x": {
                    "ticks": {"color": "#183049"},
                    "grid": {"display": False},
                },
                "y": {
                    "ticks": {"color": "#183049"},
                    "grid": {"color": "rgba(24, 48, 73, 0.10)"},
                    "beginAtZero": True,
                },
            },
        },
    }


def _build_performance_insights(summary: dict, filters: dict) -> dict:
    municipality_rows = list(summary.get("municipality_vote_rows", []))
    province_rows = list(summary.get("province_vote_rows", []))

    if filters["selected_municipality"] != ALL_FILTER:
        base_rows = [
            row for row in municipality_rows if row["name"] == filters["selected_municipality"]
        ]
        level_label = "Selected City / Municipality"
    elif municipality_rows:
        base_rows = municipality_rows
        level_label = "City / Municipality"
    else:
        base_rows = province_rows
        level_label = "Province / District"

    return {
        "level_label": level_label,
        "top_performing_rows": sorted(
            base_rows,
            key=lambda item: (item["candidate_share_of_location_votes"], item["candidate_votes"]),
            reverse=True,
        )[:10],
        "lowest_performing_rows": sorted(
            base_rows,
            key=lambda item: (item["candidate_share_of_location_votes"], item["candidate_votes"]),
        )[:10],
        "biggest_contributor_rows": sorted(
            base_rows,
            key=lambda item: (item["candidate_vote_share_of_scope"], item["candidate_votes"]),
            reverse=True,
        )[:10],
    }


def _safe_filename_part(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value or "").encode("ascii", "ignore").decode("ascii")
    cleaned = re.sub(r"[^A-Za-z0-9]+", "-", normalized).strip("-").lower()
    return cleaned or "scope"


def _compare_export_filename(candidate_a: Candidate, candidate_b: Candidate, dashboard: dict, extension: str) -> str:
    return (
        f"compare-{_safe_filename_part(candidate_a.last_name)}-vs-{_safe_filename_part(candidate_b.last_name)}"
        f"-{_safe_filename_part(dashboard['comparison_label'])}.{extension}"
    )


def _compare_export_urls(candidate_a: Candidate, candidate_b: Candidate, filters: dict, comparison_level: str) -> dict:
    params = {
        "candidate_a": candidate_a.id,
        "candidate_b": candidate_b.id,
        "region": filters["selected_region"],
        "province": filters["selected_province"],
        "municipality": filters["selected_municipality"],
    }
    if comparison_level in {"summary", "barangay"}:
        params["comparison_level"] = comparison_level

    base_url = reverse("senators:compare_senators")
    return {
        "csv": f"{base_url}?{urlencode({**params, 'export': 'csv'})}",
        "pdf": f"{base_url}?{urlencode({**params, 'export': 'pdf'})}",
    }


def _build_compare_winner_summary(dashboard: dict, candidate_a: Candidate, candidate_b: Candidate) -> dict:
    rows = list(dashboard.get("comparison_rows", []))
    wins_a = sum(1 for row in rows if row["candidate_a_votes"] > row["candidate_b_votes"])
    wins_b = sum(1 for row in rows if row["candidate_b_votes"] > row["candidate_a_votes"])
    ties = sum(1 for row in rows if row["candidate_a_votes"] == row["candidate_b_votes"])

    if rows:
        widest_row = max(rows, key=lambda row: abs(row["vote_gap"]))
        if widest_row["vote_gap"] > 0:
            widest_winner = candidate_a.full_name
        elif widest_row["vote_gap"] < 0:
            widest_winner = candidate_b.full_name
        else:
            widest_winner = "Tie"
    else:
        widest_row = None
        widest_winner = ""

    total_gap = dashboard["candidate_a_totals"]["candidate_votes"] - dashboard["candidate_b_totals"]["candidate_votes"]
    if total_gap > 0:
        scope_leader = candidate_a.full_name
    elif total_gap < 0:
        scope_leader = candidate_b.full_name
    else:
        scope_leader = "Tie"

    return {
        "cards": [
            {
                "label": f"{candidate_a.full_name} Areas Won",
                "value": wins_a,
                "detail": dashboard["comparison_label"],
            },
            {
                "label": f"{candidate_b.full_name} Areas Won",
                "value": wins_b,
                "detail": dashboard["comparison_label"],
            },
            {
                "label": "Tied Areas",
                "value": ties,
                "detail": dashboard["comparison_label"],
            },
            {
                "label": "Scope Vote Leader",
                "value": scope_leader,
                "detail": f"{abs(total_gap):,} vote gap" if total_gap else "Dead heat",
            },
        ],
        "widest_lead": {
            "winner": widest_winner,
            "location": widest_row["name"] if widest_row else "No area data",
            "gap": abs(widest_row["vote_gap"]) if widest_row else 0,
        },
    }


def _export_compare_csv(candidate_a: Candidate, candidate_b: Candidate, dashboard: dict) -> HttpResponse:
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = (
        f'attachment; filename="{_compare_export_filename(candidate_a, candidate_b, dashboard, "csv")}"'
    )
    response.write("\ufeff")
    writer = csv.writer(response)
    writer.writerow(
        [
            dashboard["comparison_label"],
            f"{candidate_a.full_name} Votes",
            f"{candidate_b.full_name} Votes",
            "Vote Gap",
            f"{candidate_a.full_name} Share",
            f"{candidate_b.full_name} Share",
        ]
    )
    for row in dashboard["comparison_rows"]:
        writer.writerow(
            [
                row["name"],
                row["candidate_a_votes"],
                row["candidate_b_votes"],
                row["vote_gap"],
                f'{row["candidate_a_share"]:.2f}%',
                f'{row["candidate_b_share"]:.2f}%',
            ]
        )
    return response


def _export_compare_pdf(
    candidate_a: Candidate,
    candidate_b: Candidate,
    dashboard: dict,
    filters: dict,
    scope_label: str,
    winner_summary: dict,
) -> HttpResponse:
    buffer = BytesIO()
    document = SimpleDocTemplate(
        buffer,
        pagesize=landscape(letter),
        leftMargin=24,
        rightMargin=24,
        topMargin=24,
        bottomMargin=24,
    )
    styles = getSampleStyleSheet()
    elements = [
        Paragraph("Senatorial Comparison Export", styles["Title"]),
        Spacer(1, 8),
        Paragraph(
            f"{candidate_a.full_name} vs {candidate_b.full_name} | Scope: {scope_label}",
            styles["Heading2"],
        ),
        Spacer(1, 6),
        Paragraph(
            (
                f"Region: {filters['selected_region']} | Province / District: {filters['selected_province']} | "
                f"Municipality / City: {filters['selected_municipality']} | Comparison Level: {dashboard['comparison_label']}"
            ),
            styles["BodyText"],
        ),
        Spacer(1, 10),
        Paragraph(
            (
                f"Widest lead: {winner_summary['widest_lead']['winner']} in "
                f"{winner_summary['widest_lead']['location']} (+{winner_summary['widest_lead']['gap']:,})"
            ),
            styles["BodyText"],
        ),
        Spacer(1, 12),
    ]

    table_data = [
        [
            dashboard["comparison_label"],
            "Candidate A Votes",
            "Candidate B Votes",
            "Vote Gap",
            "Candidate A Share",
            "Candidate B Share",
        ]
    ]
    for row in dashboard["comparison_rows"]:
        table_data.append(
            [
                row["name"],
                f'{row["candidate_a_votes"]:,}',
                f'{row["candidate_b_votes"]:,}',
                f'{row["vote_gap"]:,}',
                f'{row["candidate_a_share"]:.2f}%',
                f'{row["candidate_b_share"]:.2f}%',
            ]
        )

    table = Table(
        table_data,
        repeatRows=1,
        colWidths=[220, 90, 90, 80, 90, 90],
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#16324f")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
                ("ALIGN", (0, 0), (0, -1), "LEFT"),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d0d7de")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.HexColor("#f7f0df")]),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    elements.append(table)
    document.build(elements)

    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = (
        f'attachment; filename="{_compare_export_filename(candidate_a, candidate_b, dashboard, "pdf")}"'
    )
    response.write(buffer.getvalue())
    return response


def _compare_chart(candidate_a, candidate_b, rows, comparison_label, label_key="name", full_label_key="name"):
    colors = _chart_colors()
    return {
        "type": "bar",
        "data": {
            "labels": [row[label_key] for row in rows],
            "datasets": [
                {
                    "label": candidate_a.full_name,
                    "data": [row["candidate_a_votes"] for row in rows],
                    "backgroundColor": colors["primary"],
                    "borderRadius": 10,
                },
                {
                    "label": candidate_b.full_name,
                    "data": [row["candidate_b_votes"] for row in rows],
                    "backgroundColor": colors["accent"],
                    "borderRadius": 10,
                },
            ],
        },
        "meta": {
            "fullLabels": [row[full_label_key] for row in rows],
        },
        "options": {
            "responsive": True,
            "maintainAspectRatio": False,
            "plugins": {
                "legend": {
                    "labels": {"color": "#183049"},
                },
            },
            "scales": {
                "x": {
                    "ticks": {"color": "#183049"},
                    "grid": {"display": False},
                    "title": {"display": True, "text": comparison_label, "color": "#183049"},
                },
                "y": {
                    "ticks": {"color": "#183049"},
                    "grid": {"color": "rgba(24, 48, 73, 0.10)"},
                    "beginAtZero": True,
                },
            },
        },
    }


@lru_cache(maxsize=256)
def _load_map_geojson(filename):
    path = Path(filename)
    if not path.is_absolute():
        path = MAP_DATA_DIR / path
    return json.loads(path.read_text(encoding="utf-8"))


def _normalize_map_name(value: str) -> str:
    ascii_text = unicodedata.normalize("NFKD", value or "").encode("ascii", "ignore").decode("ascii")
    normalized = re.sub(r"[^A-Z0-9]+", " ", ascii_text.upper()).strip()
    aliases = {
        "PASAY CITY": "CITY OF PASAY",
    }
    return aliases.get(normalized, normalized)


def _canonical_province_name(value: str) -> str:
    normalized = _normalize_map_name(value)
    return PROVINCE_NAME_ALIASES.get(normalized, value)


def _faeldon_region_code(region_name: str) -> str:
    return REGION_CODE_LOOKUP.get(_normalize_map_name(region_name), "")


def _faeldon_region_province_file(region_name: str):
    code = _faeldon_region_code(region_name)
    if not code:
        return None
    path = Path("faeldon") / "regions" / "lowres" / f"provdists-region-{code}.0.001.json"
    return path if (MAP_DATA_DIR / path).exists() else None


@lru_cache(maxsize=32)
def _faeldon_region_province_index(region_name: str):
    path = _faeldon_region_province_file(region_name)
    if not path:
        return {}
    geojson = _load_map_geojson(path)
    index = {}
    for feature in geojson.get("features") or []:
        properties = feature.get("properties") or {}
        province_code = str(properties.get("adm2_psgc") or "")
        province_name = _canonical_province_name(properties.get("adm2_en", ""))
        index[province_code] = province_name
    return index


def _faeldon_province_code(region_name: str, province_name: str) -> str:
    target = _normalize_map_name(province_name)
    for province_code, display_name in _faeldon_region_province_index(region_name).items():
        if _normalize_map_name(display_name) == target:
            return province_code
    return ""


def _faeldon_municipality_file(province_code: str):
    if not province_code:
        return None
    path = Path("faeldon") / "provdists" / "lowres" / f"municities-provdist-{province_code}.0.001.json"
    return path if (MAP_DATA_DIR / path).exists() else None


def _annotated_province_geojson(region_name: str):
    path = _faeldon_region_province_file(region_name)
    if not path:
        return None
    source = _load_map_geojson(path)
    features = []
    for feature in source.get("features") or []:
        properties = dict(feature.get("properties") or {})
        province_name = _canonical_province_name(properties.get("adm2_en", ""))
        properties["map_name"] = province_name
        properties["map_scope_key"] = province_name
        features.append({**feature, "properties": properties})
    return {"type": "FeatureCollection", "features": features}


def _annotated_municipality_geojson(region_name: str, province_name: str):
    province_index = _faeldon_region_province_index(region_name)
    if not province_index:
        return None

    if province_name != ALL_FILTER:
        province_codes = [_faeldon_province_code(region_name, province_name)]
    else:
        province_codes = list(province_index.keys())

    features = []
    for province_code in province_codes:
        path = _faeldon_municipality_file(province_code)
        if not path:
            continue
        source = _load_map_geojson(path)
        province_display = province_index.get(province_code, "")
        for feature in source.get("features") or []:
            properties = dict(feature.get("properties") or {})
            municipality_name = properties.get("adm3_en", "")
            properties["map_name"] = municipality_name
            properties["map_scope_key"] = f"{province_display} || {municipality_name}" if province_display else municipality_name
            features.append({**feature, "properties": properties})

    if not features:
        return None
    return {"type": "FeatureCollection", "features": features}


def _iter_geometry_points(coordinates):
    if isinstance(coordinates, (list, tuple)) and coordinates:
        first = coordinates[0]
        if isinstance(first, (int, float)) and len(coordinates) >= 2:
            yield coordinates[0], coordinates[1]
        else:
            for item in coordinates:
                yield from _iter_geometry_points(item)


def _feature_rings(feature: dict):
    geometry = feature.get("geometry") or {}
    geom_type = geometry.get("type")
    coordinates = geometry.get("coordinates") or []
    if geom_type == "Polygon":
        return [coordinates]
    if geom_type == "MultiPolygon":
        return coordinates
    return []


def _svg_fill_color(intensity: float) -> str:
    clamped = max(0.0, min(1.0, intensity))
    start = (214, 226, 238)
    end = (36, 69, 99)
    rgb = tuple(round(start[i] + (end[i] - start[i]) * clamped) for i in range(3))
    return f"rgb({rgb[0]}, {rgb[1]}, {rgb[2]})"


def _build_svg_map_from_geojson(geojson, rows, property_name: str, tooltip_property: str | None = None):
    features = geojson.get("features") or []
    if not features:
        return None

    all_points = []
    for feature in features:
        all_points.extend(list(_iter_geometry_points((feature.get("geometry") or {}).get("coordinates"))))
    if not all_points:
        return None

    min_lon = min(point[0] for point in all_points)
    max_lon = max(point[0] for point in all_points)
    min_lat = min(point[1] for point in all_points)
    max_lat = max(point[1] for point in all_points)

    width = 860
    height = 380
    padding = 18
    scale_x = (width - padding * 2) / max(max_lon - min_lon, 0.000001)
    scale_y = (height - padding * 2) / max(max_lat - min_lat, 0.000001)
    scale = min(scale_x, scale_y)
    used_width = (max_lon - min_lon) * scale
    used_height = (max_lat - min_lat) * scale
    offset_x = padding + ((width - padding * 2) - used_width) / 2
    offset_y = padding + ((height - padding * 2) - used_height) / 2

    def project(lon, lat):
        x = offset_x + (lon - min_lon) * scale
        y = offset_y + (max_lat - lat) * scale
        return x, y

    row_lookup = {_normalize_map_name(row.get("scope_key", row["name"])): row for row in rows}
    max_votes = max((row["candidate_votes"] for row in rows), default=1) or 1

    svg_features = []
    for feature in features:
        properties = feature.get("properties") or {}
        scope_key = properties.get(property_name, "")
        label = properties.get(tooltip_property or property_name, scope_key or "Unknown area")
        row = row_lookup.get(_normalize_map_name(label))
        if scope_key:
            row = row_lookup.get(_normalize_map_name(scope_key)) or row
        votes = row["candidate_votes"] if row else 0
        intensity = votes / max_votes if votes else 0

        path_parts = []
        for polygon in _feature_rings(feature):
            for ring in polygon:
                points = [project(lon, lat) for lon, lat in ring]
                if not points:
                    continue
                segments = [f"{x:.2f},{y:.2f}" for x, y in points]
                path_parts.append("M " + " L ".join(segments) + " Z")

        if row:
            tooltip = (
                f"{label} | Candidate votes: {row['candidate_votes']:,} | "
                f"Candidate share in area: {row['candidate_share_of_location_votes']:.2f}%"
            )
        else:
            tooltip = f"{label} | No imported vote data"

        svg_features.append(
            {
                "label": label,
                "path": " ".join(path_parts),
                "fill": _svg_fill_color(intensity) if row else "#d7dde5",
                "stroke": "#244563" if row else "#8898a9",
                "stroke_width": 2 if row else 1.5,
                "dasharray": "" if row else "4 4",
                "tooltip": tooltip,
            }
        )

    return {
        "width": width,
        "height": height,
        "features": svg_features,
    }


def _build_svg_map(filename: str, rows, property_name: str, tooltip_property: str | None = None):
    return _build_svg_map_from_geojson(
        _load_map_geojson(filename),
        rows,
        property_name,
        tooltip_property=tooltip_property,
    )


def _scope_label(filters: dict) -> str:
    if filters["selected_municipality"] != ALL_FILTER:
        return filters["selected_municipality"]
    if filters["selected_province"] != ALL_FILTER:
        return filters["selected_province"]
    return filters["selected_region"]


def _municipality_chart_limit(filters: dict) -> int:
    if filters["selected_municipality"] != ALL_FILTER:
        return 20
    if filters["selected_province"] != ALL_FILTER:
        return 30
    if filters["selected_region"] != ALL_FILTER:
        return 30
    return 10


def _location_context(request):
    return resolve_location_filters(
        request.GET.get("region"),
        request.GET.get("province"),
        request.GET.get("municipality"),
    )


def home(request):
    regions = get_regions()
    return render(
        request,
        "senators/home.html",
        {
            "candidate_count": Candidate.objects.count(),
            "region_count": len(regions),
            "dataset_banner": _dataset_banner(),
            "notes": _build_dataset_notes(regions),
        },
    )


def senator_list(request):
    search = request.GET.get("q", "").strip()
    regions = get_regions()
    senators = candidate_search_queryset(search)
    return render(
        request,
        "senators/senator_list.html",
        {
            "senators": senators,
            "search": search,
            "dataset_banner": _dataset_banner(),
            "notes": _build_dataset_notes(regions),
        },
    )


def senator_detail(request, candidate_id: int):
    candidate = get_object_or_404(Candidate, pk=candidate_id)
    next_candidate_id = (request.GET.get("inspect_candidate") or "").strip()
    ml_reference = (request.GET.get("ml_reference") or "").strip()
    if next_candidate_id and next_candidate_id != str(candidate_id):
        if Candidate.objects.filter(pk=next_candidate_id).exists():
            redirect_query = request.GET.copy()
            redirect_query.pop("inspect_candidate", None)
            target_url = reverse("senators:senator_detail", args=[next_candidate_id])
            if redirect_query:
                target_url = f"{target_url}?{redirect_query.urlencode()}"
            return redirect(target_url)

    regions = get_regions()
    filters = _location_context(request)

    summary = compute_candidate_dashboard(
        candidate,
        filters["selected_region"],
        filters["selected_province"],
        filters["selected_municipality"],
    )
    ml_insights = build_candidate_ml_insights(
        candidate,
        summary,
        filters["selected_region"],
        filters["selected_province"],
        filters["selected_municipality"],
        reference_area=ml_reference,
    )
    performance_insights = _build_performance_insights(summary, filters)

    colors = _chart_colors()
    province_chart_rows = _notation_rows(summary["province_vote_rows"][:10])
    municipality_chart_rows = _notation_rows(
        summary["municipality_vote_rows"][:_municipality_chart_limit(filters)]
    )
    province_chart = _single_series_chart(
        "Candidate Votes by Province / District",
        province_chart_rows,
        "candidate_votes",
        colors["primary"],
        label_key="notation",
    )
    municipality_chart = _single_series_chart(
        "Candidate Votes by City",
        municipality_chart_rows,
        "candidate_votes",
        colors["accent"],
        label_key="notation",
    )

    selected_region = filters["selected_region"]
    province_svg_map = None
    municipality_svg_map = None
    if selected_region != ALL_FILTER:
        province_geojson = _annotated_province_geojson(selected_region)
        if province_geojson:
            province_svg_map = _build_svg_map_from_geojson(
                province_geojson,
                summary["province_vote_rows"],
                "map_scope_key",
                tooltip_property="map_name",
            )
        municipality_geojson = _annotated_municipality_geojson(
            selected_region,
            filters["selected_province"],
        )
        if municipality_geojson:
            municipality_svg_map = _build_svg_map_from_geojson(
                municipality_geojson,
                summary["municipality_vote_rows"],
                "map_scope_key",
                tooltip_property="map_name",
            )

    return render(
        request,
        "senators/senator_detail.html",
        {
            "candidate": candidate,
            "candidate_headshot_url": _candidate_headshot_url(candidate),
            "default_headshot_url": static("senators/img/default_headshot.svg"),
            "candidate_options": Candidate.objects.all(),
            "filters": filters,
            "summary": summary,
            "ml_insights": ml_insights,
            "performance_insights": performance_insights,
            "province_chart": province_chart,
            "municipality_chart": municipality_chart,
            "province_chart_rows": province_chart_rows,
            "municipality_chart_rows": municipality_chart_rows,
            "province_svg_map": province_svg_map,
            "municipality_svg_map": municipality_svg_map,
            "scope_label": _scope_label(filters),
            "dataset_banner": _dataset_banner(),
            "notes": _build_dataset_notes(regions),
        },
    )


def compare_senators(request):
    regions = get_regions()
    filters = _location_context(request)
    candidates = list(Candidate.objects.all())
    comparison_level = (request.GET.get("comparison_level") or "").strip().lower()
    export_format = (request.GET.get("export") or "").strip().lower()

    candidate_a_id = request.GET.get("candidate_a") or (str(candidates[0].id) if candidates else "")
    candidate_b_id = request.GET.get("candidate_b") or (str(candidates[1].id) if len(candidates) > 1 else candidate_a_id)

    candidate_a = get_object_or_404(Candidate, pk=candidate_a_id)
    candidate_b = get_object_or_404(Candidate, pk=candidate_b_id)

    dashboard = build_compare_dashboard(
        candidate_a,
        candidate_b,
        filters["selected_region"],
        filters["selected_province"],
        filters["selected_municipality"],
        comparison_level=comparison_level,
    )
    winner_summary = _build_compare_winner_summary(dashboard, candidate_a, candidate_b)
    scope_label = _scope_label(filters)

    if export_format == "csv":
        return _export_compare_csv(candidate_a, candidate_b, dashboard)
    if export_format == "pdf":
        return _export_compare_pdf(candidate_a, candidate_b, dashboard, filters, scope_label, winner_summary)

    comparison_chart_rows = _notation_rows(dashboard["comparison_rows"][:12])
    comparison_chart = _compare_chart(
        candidate_a,
        candidate_b,
        comparison_chart_rows,
        dashboard["comparison_label"],
        label_key="notation",
    )

    return render(
        request,
        "senators/compare_senators.html",
        {
            "candidates": candidates,
            "candidate_a": candidate_a,
            "candidate_b": candidate_b,
            "candidate_a_headshot_url": _candidate_headshot_url(candidate_a),
            "candidate_b_headshot_url": _candidate_headshot_url(candidate_b),
            "default_headshot_url": static("senators/img/default_headshot.svg"),
            "filters": filters,
            "comparison_level": dashboard["comparison_mode"],
            "scope_label": scope_label,
            "dashboard": dashboard,
            "winner_summary": winner_summary,
            "compare_export_urls": _compare_export_urls(
                candidate_a,
                candidate_b,
                filters,
                dashboard["comparison_mode"],
            ),
            "comparison_chart": comparison_chart,
            "comparison_chart_rows": comparison_chart_rows,
            "dataset_banner": _dataset_banner(),
            "notes": _build_dataset_notes(regions),
        },
    )


def barangay_drilldown(request, candidate_id: int):
    candidate = get_object_or_404(Candidate, pk=candidate_id)
    regions = get_regions()
    filters = _location_context(request)
    summary = compute_barangay_dashboard(
        candidate,
        filters["selected_region"],
        filters["selected_province"],
        filters["selected_municipality"],
    )
    barangay_chart = _single_series_chart(
        "Candidate Votes by Barangay",
        summary["barangay_rows"][:15],
        "candidate_votes",
        _chart_colors()["soft"],
    )

    return render(
        request,
        "senators/barangay_drilldown.html",
        {
            "candidate": candidate,
            "filters": filters,
            "summary": summary,
            "barangay_chart": barangay_chart,
            "scope_label": _scope_label(filters),
            "dataset_banner": _dataset_banner(),
            "notes": _build_dataset_notes(regions),
        },
    )
