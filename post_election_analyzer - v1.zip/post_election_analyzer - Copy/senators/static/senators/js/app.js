(function () {
    function parseJsonScript(id) {
        const element = document.getElementById(id);
        if (!element) {
            return null;
        }
        return JSON.parse(element.textContent);
    }

    function normalizeText(value) {
        return (value || "")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toUpperCase()
            .replace(/[^A-Z0-9]+/g, " ")
            .replace(/\s+/g, " ")
            .trim();
    }

    const provinceAliases = {
        "NCR CITY OF MANILA FIRST DISTRICT NOT A PROVINCE": "NATIONAL CAPITAL REGION MANILA",
        "NCR SECOND DISTRICT NOT A PROVINCE": "NATIONAL CAPITAL REGION SECOND DISTRICT",
        "NCR THIRD DISTRICT NOT A PROVINCE": "NATIONAL CAPITAL REGION THIRD DISTRICT",
        "NCR FOURTH DISTRICT NOT A PROVINCE": "NATIONAL CAPITAL REGION FOURTH DISTRICT",
    };
    const locationAliases = {
        "PASAY CITY": "CITY OF PASAY",
    };

    function normalizeByLevel(value, level) {
        const normalized = normalizeText(value);
        if (level === "province") {
            return provinceAliases[normalized] || normalized;
        }
        return locationAliases[normalized] || normalized;
    }

    function rebuildSelectOptions(select, options, selectedValue, allLabel) {
        if (!select) {
            return;
        }

        const allOption = select.querySelector('option[value="ALL"]');
        const allText = allLabel || (allOption ? allOption.textContent : "ALL");

        select.innerHTML = "";
        const firstOption = document.createElement("option");
        firstOption.value = "ALL";
        firstOption.textContent = allText;
        if (selectedValue === "ALL") {
            firstOption.selected = true;
        }
        select.appendChild(firstOption);

        options.forEach((optionValue) => {
            const option = document.createElement("option");
            option.value = optionValue;
            option.textContent = optionValue;
            if (optionValue === selectedValue) {
                option.selected = true;
            }
            select.appendChild(option);
        });
    }

    function initCascadingFilters() {
        const locationTree = parseJsonScript("location-tree-data");
        if (!locationTree) {
            return;
        }

        document.querySelectorAll("[data-location-form]").forEach((form) => {
            const regionSelect = form.querySelector('select[name="region"]');
            const provinceSelect = form.querySelector('select[name="province"]');
            const municipalitySelect = form.querySelector('select[name="municipality"]');

            if (!regionSelect || !provinceSelect || !municipalitySelect) {
                return;
            }

            const provinceAllLabel = provinceSelect.querySelector('option[value="ALL"]')?.textContent || "ALL";
            const municipalityAllLabel = municipalitySelect.querySelector('option[value="ALL"]')?.textContent || "ALL";

            function provinceOptions(regionValue) {
                return Object.keys(locationTree[regionValue] || {}).sort();
            }

            function municipalityOptions(regionValue, provinceValue) {
                if (!regionValue || !locationTree[regionValue]) {
                    return [];
                }
                if (provinceValue && provinceValue !== "ALL") {
                    return (locationTree[regionValue][provinceValue] || []).slice().sort();
                }

                const set = new Set();
                Object.values(locationTree[regionValue]).forEach((municipalities) => {
                    municipalities.forEach((municipality) => set.add(municipality));
                });
                return Array.from(set).sort();
            }

            function syncProvinceAndMunicipality() {
                const nextProvinces = provinceOptions(regionSelect.value);
                const provinceSelected =
                    nextProvinces.indexOf(provinceSelect.value) >= 0 ? provinceSelect.value : "ALL";
                rebuildSelectOptions(provinceSelect, nextProvinces, provinceSelected, provinceAllLabel);

                const nextMunicipalities = municipalityOptions(regionSelect.value, provinceSelect.value);
                const municipalitySelected =
                    nextMunicipalities.indexOf(municipalitySelect.value) >= 0
                        ? municipalitySelect.value
                        : "ALL";
                rebuildSelectOptions(
                    municipalitySelect,
                    nextMunicipalities,
                    municipalitySelected,
                    municipalityAllLabel
                );
            }

            regionSelect.addEventListener("change", () => {
                syncProvinceAndMunicipality();
            });

            provinceSelect.addEventListener("change", () => {
                const nextMunicipalities = municipalityOptions(regionSelect.value, provinceSelect.value);
                rebuildSelectOptions(
                    municipalitySelect,
                    nextMunicipalities,
                    "ALL",
                    municipalityAllLabel
                );
            });
        });
    }

    function initCharts() {
        if (typeof Chart === "undefined") {
            return;
        }

        document.querySelectorAll("canvas[data-chart-config-id]").forEach((canvas) => {
            const existingChart =
                typeof Chart.getChart === "function" ? Chart.getChart(canvas) : canvas._chartInstance;
            if (existingChart) {
                return;
            }
            const config = parseJsonScript(canvas.dataset.chartConfigId);
            if (!config || !config.data || !config.data.labels || config.data.labels.length === 0) {
                return;
            }
            const fullLabels = config.meta?.fullLabels || [];
            if (fullLabels.length) {
                config.options = config.options || {};
                config.options.plugins = config.options.plugins || {};
                config.options.plugins.tooltip = config.options.plugins.tooltip || {};
                config.options.plugins.tooltip.callbacks = {
                    ...(config.options.plugins.tooltip.callbacks || {}),
                    title(items) {
                        const item = items && items[0];
                        if (!item) {
                            return "";
                        }
                        return fullLabels[item.dataIndex] || item.label || "";
                    },
                };
            }
            canvas._chartInstance = new Chart(canvas, config);
        });
    }

    function styleColor(intensity) {
        const clamped = Math.max(0.08, Math.min(1, intensity));
        const alpha = 0.15 + clamped * 0.75;
        return `rgba(22, 50, 79, ${alpha.toFixed(2)})`;
    }

    function createLegend(container) {
        const legend = document.createElement("div");
        legend.className = "map-legend";
        legend.innerHTML = [
            '<span class="map-legend-item"><span class="map-legend-swatch"></span><span>Lower votes to higher votes</span></span>',
            '<span class="map-legend-item"><span class="map-legend-swatch map-legend-swatch-empty"></span><span>No imported data</span></span>',
        ].join("");
        container.parentElement?.appendChild(legend);
    }

    function initMaps(root = document) {
        if (typeof L === "undefined") {
            return;
        }

        root.querySelectorAll(".leaflet-map[data-map-config-id]").forEach((container) => {
            if (container._leafletMap) {
                return;
            }
            const config = parseJsonScript(container.dataset.mapConfigId);
            if (!config) {
                return;
            }

            const rows = config.rows || [];
            const lookup = new Map();
            rows.forEach((row) => {
                lookup.set(normalizeByLevel(row.name, config.level), row);
            });
            const maxVotes = Math.max(1, ...rows.map((row) => row.candidate_votes || 0));

            const map = L.map(container, {
                attributionControl: false,
                scrollWheelZoom: false,
            });
            map.setView([14.6091, 121.0223], 10);
            container._leafletMap = map;

            fetch(config.geojsonUrl)
                .then((response) => response.json())
                .then((geojson) => {
                    const layer = L.geoJSON(geojson, {
                        style: (feature) => {
                            const rawName = feature?.properties?.[config.featureProperty] || "";
                            const row = lookup.get(normalizeByLevel(rawName, config.level));
                            const votes = row ? row.candidate_votes : 0;
                            return {
                                color: votes ? "#244563" : "#8898a9",
                                weight: votes ? 2 : 1.5,
                                dashArray: votes ? null : "4 4",
                                fillColor: votes ? styleColor(votes / maxVotes) : "#d7dde5",
                                fillOpacity: votes ? 0.88 : 0.55,
                            };
                        },
                        onEachFeature: (feature, featureLayer) => {
                            const rawName = feature?.properties?.[config.featureProperty] || "Unknown area";
                            const row = lookup.get(normalizeByLevel(rawName, config.level));
                            if (row) {
                                const votes = row.candidate_votes.toLocaleString();
                                const share = `${Number(row.candidate_share_of_location_votes).toFixed(2)}%`;
                                featureLayer.bindPopup(
                                    `<strong>${rawName}</strong><br>Candidate votes: ${votes}<br>Candidate share in area: ${share}`
                                );
                            } else {
                                featureLayer.bindPopup(
                                    `<strong>${rawName}</strong><br>No imported vote data is available for this area.`
                                );
                            }

                            featureLayer.on({
                                mouseover() {
                                    featureLayer.setStyle({
                                        weight: 2.6,
                                        fillOpacity: row ? 0.96 : 0.68,
                                    });
                                },
                                mouseout() {
                                    layer.resetStyle(featureLayer);
                                },
                            });
                        },
                    }).addTo(map);
                    container._leafletLayer = layer;
                    layer.eachLayer((featureLayer) => {
                        if (typeof featureLayer.bringToFront === "function") {
                            featureLayer.bringToFront();
                        }
                    });

                    const bounds = layer.getBounds();
                    if (bounds.isValid()) {
                        container._leafletBounds = bounds;
                        map.fitBounds(bounds, { padding: [16, 16] });
                    }

                    createLegend(container);
                })
                .catch(() => {
                    container.innerHTML = '<p class="muted">Map data could not be loaded.</p>';
                });
        });
    }

    function refreshCharts(panel) {
        if (typeof Chart === "undefined" || !panel) {
            return;
        }

        panel.querySelectorAll("canvas[data-chart-config-id]").forEach((canvas) => {
            const chart =
                (typeof Chart.getChart === "function" ? Chart.getChart(canvas) : null) || canvas._chartInstance;
            if (!chart) {
                return;
            }
            chart.resize();
            chart.update("none");
        });
    }

    function refreshMaps(panel) {
        if (!panel) {
            return;
        }

        panel.querySelectorAll(".leaflet-map[data-map-config-id]").forEach((container) => {
            const map = container._leafletMap;
            if (!map) {
                return;
            }
            [90, 260].forEach((delay) => {
                window.setTimeout(() => {
                    map.invalidateSize();
                    if (container._leafletBounds && container._leafletBounds.isValid()) {
                        map.fitBounds(container._leafletBounds, { padding: [16, 16] });
                    }
                    if (container._leafletLayer) {
                        container._leafletLayer.eachLayer((featureLayer) => {
                            if (typeof featureLayer.redraw === "function") {
                                featureLayer.redraw();
                            }
                            if (typeof featureLayer.bringToFront === "function") {
                                featureLayer.bringToFront();
                            }
                        });
                    }
                }, delay);
            });
        });
    }

    function initProfileTabs() {
        document.querySelectorAll("[data-profile-tabs]").forEach((nav) => {
            const card = nav.closest(".profile-main-card");
            if (!card) {
                return;
            }

            const scrollContainer = card.querySelector(".profile-main-scroll");
            const buttons = Array.from(nav.querySelectorAll("[data-panel-button]"));
            const panels = Array.from(card.querySelectorAll(".profile-tab-panel"));

            if (!buttons.length || !panels.length) {
                return;
            }

            function activatePanel(panelName) {
                let nextPanel = null;

                buttons.forEach((button) => {
                    const isActive = button.dataset.panelButton === panelName;
                    button.classList.toggle("active", isActive);
                    button.setAttribute("aria-selected", isActive ? "true" : "false");
                });

                panels.forEach((panel) => {
                    const isActive = panel.dataset.panel === panelName;
                    panel.classList.toggle("active", isActive);
                    panel.hidden = !isActive;
                    if (isActive) {
                        nextPanel = panel;
                    }
                });

                if (!nextPanel) {
                    return;
                }

                if (scrollContainer) {
                    scrollContainer.scrollTop = 0;
                }

                window.requestAnimationFrame(() => {
                    initMaps(nextPanel);
                    refreshCharts(nextPanel);
                    refreshMaps(nextPanel);
                });
            }

            buttons.forEach((button, index) => {
                button.addEventListener("click", () => {
                    activatePanel(button.dataset.panelButton);
                });

                button.addEventListener("keydown", (event) => {
                    if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") {
                        return;
                    }

                    event.preventDefault();
                    const direction = event.key === "ArrowRight" ? 1 : -1;
                    const nextIndex = (index + direction + buttons.length) % buttons.length;
                    buttons[nextIndex].focus();
                    activatePanel(buttons[nextIndex].dataset.panelButton);
                });
            });

            const defaultButton = buttons.find((button) => button.classList.contains("active")) || buttons[0];
            activatePanel(defaultButton.dataset.panelButton);
        });
    }

    function parseSortableValue(cell, type) {
        const rawValue = cell?.dataset.sortValue || cell?.textContent || "";
        if (type === "number") {
            const parsed = Number.parseFloat(String(rawValue).replace(/,/g, "").replace(/%/g, ""));
            return Number.isFinite(parsed) ? parsed : Number.NEGATIVE_INFINITY;
        }
        return String(rawValue).trim().toUpperCase();
    }

    function initInteractiveTables() {
        document.querySelectorAll("[data-table-shell]").forEach((shell) => {
            const table = shell.querySelector("table[data-interactive-table]");
            const tbody = table?.tBodies?.[0];
            if (!table || !tbody) {
                return;
            }

            const rows = Array.from(tbody.querySelectorAll("tr[data-table-row]"));
            if (!rows.length) {
                return;
            }

            rows.forEach((row, index) => {
                row.dataset.originalIndex = String(index);
                row.dataset.filterText = normalizeText(row.textContent || "");
            });

            const filterInput = shell.querySelector("[data-table-filter]");
            const resultsLabels = Array.from(shell.querySelectorAll("[data-table-results]"));
            const headerCells = Array.from(table.querySelectorAll("thead th[data-sort-type]"));
            const pagination = shell.querySelector("[data-table-pagination]");
            const pageSizeSelect = shell.querySelector("[data-table-page-size]");
            const pageInfo = shell.querySelector("[data-table-page-info]");
            const prevButton = shell.querySelector("[data-table-prev]");
            const nextButton = shell.querySelector("[data-table-next]");
            let currentSort = null;
            let currentPage = 1;

            function updateHeaderState() {
                headerCells.forEach((headerCell, index) => {
                    const isActive = currentSort && currentSort.index === index;
                    const direction = isActive ? currentSort.direction : "none";
                    headerCell.dataset.sortDirection = direction;
                    headerCell.setAttribute(
                        "aria-sort",
                        !isActive ? "none" : direction === "asc" ? "ascending" : "descending"
                    );
                });
            }

            function filteredRows() {
                const query = normalizeText(filterInput?.value || "");
                if (!query) {
                    return rows.slice();
                }
                return rows.filter((row) => row.dataset.filterText.includes(query));
            }

            function sortedRows(activeRows) {
                if (!currentSort) {
                    return activeRows.slice();
                }

                const { index, direction, type } = currentSort;
                const multiplier = direction === "asc" ? 1 : -1;

                return activeRows.slice().sort((rowA, rowB) => {
                    const valueA = parseSortableValue(rowA.cells[index], type);
                    const valueB = parseSortableValue(rowB.cells[index], type);
                    if (valueA < valueB) {
                        return -1 * multiplier;
                    }
                    if (valueA > valueB) {
                        return 1 * multiplier;
                    }
                    return Number(rowA.dataset.originalIndex) - Number(rowB.dataset.originalIndex);
                });
            }

            function updateResultsLabel(visibleCount) {
                const totalCount = rows.length;
                const rowLabel = visibleCount === 1 ? "row" : "rows";
                const message =
                    visibleCount === totalCount
                        ? `${totalCount} ${rowLabel}`
                        : `Showing ${visibleCount} of ${totalCount} rows`;
                resultsLabels.forEach((label) => {
                    label.textContent = message;
                });
            }

            function currentPageSize() {
                const parsed = Number.parseInt(pageSizeSelect?.value || table.dataset.pageSize || "25", 10);
                return Number.isFinite(parsed) && parsed > 0 ? parsed : 25;
            }

            function paginatedRows(activeRows) {
                const pageSize = currentPageSize();
                const totalPages = Math.max(1, Math.ceil(activeRows.length / pageSize));
                currentPage = Math.min(currentPage, totalPages);
                currentPage = Math.max(1, currentPage);
                const startIndex = (currentPage - 1) * pageSize;
                const endIndex = startIndex + pageSize;
                return {
                    totalPages,
                    pageRows: activeRows.slice(startIndex, endIndex),
                    totalRows: activeRows.length,
                };
            }

            function updatePagination(totalRows, totalPages) {
                if (!pagination) {
                    return;
                }

                const shouldShow = totalRows > currentPageSize();
                pagination.hidden = !shouldShow;
                if (pageInfo) {
                    pageInfo.textContent = shouldShow ? `Page ${currentPage} of ${totalPages}` : "Single page";
                }
                if (prevButton) {
                    prevButton.disabled = currentPage <= 1;
                }
                if (nextButton) {
                    nextButton.disabled = currentPage >= totalPages;
                }
            }

            function render(resetPage = false) {
                if (resetPage) {
                    currentPage = 1;
                }
                const activeRows = sortedRows(filteredRows());
                const { pageRows, totalPages, totalRows } = paginatedRows(activeRows);
                tbody.querySelector(".interactive-table-empty")?.remove();
                tbody.innerHTML = "";

                if (!totalRows) {
                    const emptyRow = document.createElement("tr");
                    emptyRow.className = "interactive-table-empty";
                    const emptyCell = document.createElement("td");
                    emptyCell.colSpan = headerCells.length || 1;
                    emptyCell.textContent = "No rows match the current filter.";
                    emptyRow.appendChild(emptyCell);
                    tbody.appendChild(emptyRow);
                    updateResultsLabel(0);
                    updatePagination(0, 1);
                    updateHeaderState();
                    return;
                }

                pageRows.forEach((row) => tbody.appendChild(row));
                updateResultsLabel(totalRows);
                updatePagination(totalRows, totalPages);
                updateHeaderState();
            }

            headerCells.forEach((headerCell, index) => {
                const button = headerCell.querySelector("[data-sort-index]");
                if (!button) {
                    return;
                }

                button.addEventListener("click", () => {
                    const type = headerCell.dataset.sortType || "text";
                    if (currentSort && currentSort.index === index) {
                        currentSort = {
                            ...currentSort,
                            direction: currentSort.direction === "desc" ? "asc" : "desc",
                        };
                    } else {
                        currentSort = {
                            index,
                            type,
                            direction: type === "text" ? "asc" : "desc",
                        };
                    }
                    render(true);
                });
            });

            filterInput?.addEventListener("input", () => render(true));
            pageSizeSelect?.addEventListener("change", () => render(true));
            prevButton?.addEventListener("click", () => {
                currentPage -= 1;
                render();
            });
            nextButton?.addEventListener("click", () => {
                currentPage += 1;
                render();
            });
            render(true);
        });
    }

    document.addEventListener("DOMContentLoaded", () => {
        initCascadingFilters();
        initCharts();
        initProfileTabs();
        initInteractiveTables();
    });
})();
