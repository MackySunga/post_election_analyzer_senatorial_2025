import csv
import os
import tempfile
from collections import defaultdict
from io import StringIO

from django.core.management import call_command
from django.test import TestCase

from senators.management.commands.import_lav_senatorial import parse_candidate_name
from senators.ml import build_candidate_ml_insights
from senators.models import Candidate, ElectionResult
from senators.services import (
    build_compare_dashboard,
    build_heat_tiles,
    compute_barangay_dashboard,
    compute_candidate_dashboard,
)


class AnalyticsServiceTests(TestCase):
    def setUp(self):
        self.candidate_a = Candidate.objects.create(
            ballot_number=1,
            raw_name="1. ALPHA, ANA (P1)",
            last_name="ALPHA",
            first_name="ANA",
            full_name="ANA ALPHA",
            party_code="P1",
            party_name="Party One",
        )
        self.candidate_b = Candidate.objects.create(
            ballot_number=2,
            raw_name="2. BRAVO, BEN (P2)",
            last_name="BRAVO",
            first_name="BEN",
            full_name="BEN BRAVO",
            party_code="P2",
            party_name="Party Two",
        )

        base_rows = [
            {
                "region": "REGION A",
                "province": "PROVINCE 1",
                "municipality": "CITY 1",
                "barangay": "BARANGAY 1",
                "precinct_code": "P-001",
                "total_voters": 100,
                "total_votes": 150,
                "candidate_a_votes": 70,
                "candidate_b_votes": 80,
            },
            {
                "region": "REGION A",
                "province": "PROVINCE 1",
                "municipality": "CITY 1",
                "barangay": "BARANGAY 2",
                "precinct_code": "P-002",
                "total_voters": 120,
                "total_votes": 180,
                "candidate_a_votes": 60,
                "candidate_b_votes": 120,
            },
            {
                "region": "REGION A",
                "province": "PROVINCE 2",
                "municipality": "CITY 2",
                "barangay": "BARANGAY 3",
                "precinct_code": "P-003",
                "total_voters": 90,
                "total_votes": 140,
                "candidate_a_votes": 40,
                "candidate_b_votes": 100,
            },
            {
                "region": "REGION B",
                "province": "PROVINCE 3",
                "municipality": "CITY 3",
                "barangay": "BARANGAY 4",
                "precinct_code": "P-004",
                "total_voters": 50,
                "total_votes": 60,
                "candidate_a_votes": 10,
                "candidate_b_votes": 50,
            },
        ]

        grouped = defaultdict(
            lambda: {
                "total_voters": 0,
                "total_votes": 0,
                "candidate_a_votes": 0,
                "candidate_b_votes": 0,
            }
        )
        for row in base_rows:
            scopes = [
                (ElectionResult.LEVEL_NATIONAL, "", "", "", ""),
                (ElectionResult.LEVEL_REGION, row["region"], "", "", ""),
                (ElectionResult.LEVEL_PROVINCE, row["region"], row["province"], "", ""),
                (ElectionResult.LEVEL_MUNICIPALITY, row["region"], row["province"], row["municipality"], ""),
                (ElectionResult.LEVEL_BARANGAY, row["region"], row["province"], row["municipality"], row["barangay"]),
            ]
            for scope in scopes:
                bucket = grouped[scope]
                bucket["total_voters"] += row["total_voters"]
                bucket["total_votes"] += row["total_votes"]
                bucket["candidate_a_votes"] += row["candidate_a_votes"]
                bucket["candidate_b_votes"] += row["candidate_b_votes"]

        for scope, values in grouped.items():
            level, region, province, municipality, barangay = scope
            location_code = "|".join(scope)
            for candidate, votes in (
                (self.candidate_a, values["candidate_a_votes"]),
                (self.candidate_b, values["candidate_b_votes"]),
            ):
                ElectionResult.objects.create(
                    candidate=candidate,
                    year=2025,
                    election_type="Senatorial",
                    location_level=level,
                    region=region,
                    province=province,
                    municipality=municipality,
                    barangay=barangay,
                    precinct_code=location_code,
                    votes=votes,
                    total_voters=values["total_voters"],
                    total_votes=values["total_votes"],
                    percentage=round((votes / values["total_votes"]) * 100, 2) if values["total_votes"] else 0,
                    contest_id="0",
                    source="TEST",
                )

    def test_dashboard_uses_unique_precinct_totals(self):
        summary = compute_candidate_dashboard(self.candidate_a, "REGION A")

        self.assertEqual(summary["total_voters"], 310)
        self.assertEqual(summary["candidate_votes"], 170)
        self.assertEqual(summary["total_votes_all_candidates"], 470)
        self.assertEqual(summary["candidate_scope_share"], 36.17)

        province_rows = {row["name"]: row for row in summary["province_vote_rows"]}
        self.assertEqual(province_rows["PROVINCE 1"]["candidate_votes"], 130)
        self.assertEqual(province_rows["PROVINCE 1"]["total_votes_all_candidates"], 330)
        self.assertEqual(province_rows["PROVINCE 1"]["candidate_share_of_location_votes"], 39.39)
        self.assertEqual(province_rows["PROVINCE 1"]["candidate_vote_share_of_scope"], 76.47)
        self.assertEqual(province_rows["PROVINCE 2"]["candidate_votes"], 40)
        self.assertEqual(province_rows["PROVINCE 2"]["total_votes_all_candidates"], 140)

        municipality_rows = {row["name"]: row for row in summary["municipality_vote_rows"]}
        self.assertEqual(municipality_rows["CITY 1"]["province"], "PROVINCE 1")

        self.assertEqual(summary["top_3_provinces"][0]["name"], "PROVINCE 1")
        self.assertEqual(summary["top_3_provinces"][0]["percent_of_candidate_votes_in_selected_region"], 76.47)

    def test_dashboard_supports_national_scope(self):
        summary = compute_candidate_dashboard(self.candidate_a)

        self.assertEqual(summary["selected_region"], "ALL")
        self.assertEqual(summary["total_voters"], 360)
        self.assertEqual(summary["candidate_votes"], 180)
        self.assertEqual(summary["total_votes_all_candidates"], 530)
        self.assertEqual(summary["candidate_scope_share"], 33.96)

    def test_heatmap_is_sorted_by_votes(self):
        heat_tiles = build_heat_tiles(self.candidate_a, region="REGION A", level="province")

        self.assertEqual(heat_tiles[0]["label"], "PROVINCE 1")
        self.assertEqual(heat_tiles[0]["votes"], 130)
        self.assertEqual(heat_tiles[0]["intensity"], 100.0)
        self.assertEqual(heat_tiles[1]["label"], "PROVINCE 2")
        self.assertEqual(heat_tiles[1]["intensity"], 30.77)

    def test_barangay_dashboard_uses_selected_city(self):
        summary = compute_barangay_dashboard(
            self.candidate_a,
            region="REGION A",
            province="PROVINCE 1",
            municipality="CITY 1",
        )

        self.assertEqual(summary["total_voters"], 220)
        self.assertEqual(summary["candidate_votes"], 130)
        self.assertEqual(len(summary["barangay_rows"]), 2)
        self.assertEqual(summary["barangay_rows"][0]["name"], "BARANGAY 1")

    def test_compare_dashboard_switches_to_city_level_when_province_selected(self):
        dashboard = build_compare_dashboard(
            self.candidate_a,
            self.candidate_b,
            region="REGION A",
            province="PROVINCE 1",
        )

        self.assertEqual(dashboard["comparison_field"], "municipality")
        self.assertEqual(dashboard["comparison_label"], "City")
        self.assertEqual(dashboard["comparison_rows"][0]["name"], "CITY 1")
        self.assertEqual(dashboard["comparison_rows"][0]["candidate_a_votes"], 130)
        self.assertEqual(dashboard["comparison_rows"][0]["candidate_b_votes"], 200)

    def test_compare_dashboard_defaults_to_selected_city_summary_when_city_is_selected(self):
        dashboard = build_compare_dashboard(
            self.candidate_a,
            self.candidate_b,
            region="REGION A",
            province="PROVINCE 1",
            municipality="CITY 1",
        )

        self.assertEqual(dashboard["comparison_field"], "municipality")
        self.assertEqual(dashboard["comparison_label"], "Selected City / Municipality")
        self.assertEqual(dashboard["comparison_mode"], "summary")
        self.assertEqual(len(dashboard["comparison_rows"]), 1)
        self.assertEqual(dashboard["comparison_rows"][0]["name"], "CITY 1")

    def test_compare_dashboard_can_switch_to_barangay_breakdown(self):
        dashboard = build_compare_dashboard(
            self.candidate_a,
            self.candidate_b,
            region="REGION A",
            province="PROVINCE 1",
            municipality="CITY 1",
            comparison_level="barangay",
        )

        self.assertEqual(dashboard["comparison_field"], "barangay")
        self.assertEqual(dashboard["comparison_label"], "Barangay")
        self.assertEqual(dashboard["comparison_mode"], "barangay")
        self.assertEqual(len(dashboard["comparison_rows"]), 2)
        self.assertEqual(dashboard["comparison_rows"][0]["name"], "BARANGAY 2")

    def test_ml_insights_builds_for_national_scope(self):
        summary = compute_candidate_dashboard(self.candidate_a)
        ml_insights = build_candidate_ml_insights(self.candidate_a, summary)

        self.assertTrue(ml_insights["available"])
        self.assertEqual(ml_insights["level_label"], "Province / District")
        self.assertTrue(len(ml_insights["anomaly_rows"]) >= 3)
        self.assertTrue(len(ml_insights["cluster_profiles"]) >= 2)

    def test_pages_render(self):
        self.assertEqual(self.client.get("/").status_code, 200)
        self.assertEqual(self.client.get("/senators/").status_code, 200)
        self.assertEqual(
            self.client.get(
                f"/senators/{self.candidate_a.id}/",
                {"region": "REGION A", "province": "PROVINCE 1", "municipality": "CITY 1"},
            ).status_code,
            200,
        )
        detail_response = self.client.get(f"/senators/{self.candidate_a.id}/")
        self.assertContains(detail_response, "ML Insights")
        self.assertContains(detail_response, "Turnout Anomaly Detection")
        self.assertEqual(
            self.client.get("/compare/", {"candidate_a": self.candidate_a.id, "candidate_b": self.candidate_b.id}).status_code,
            200,
        )
        self.assertEqual(
            self.client.get(
                f"/senators/{self.candidate_a.id}/barangays/",
                {"region": "REGION A", "province": "PROVINCE 1", "municipality": "CITY 1"},
            ).status_code,
            200,
        )

    def test_compare_page_includes_interactive_table_controls(self):
        response = self.client.get("/compare/", {"candidate_a": self.candidate_a.id, "candidate_b": self.candidate_b.id})

        self.assertContains(response, 'data-table-shell')
        self.assertContains(response, 'data-table-filter')
        self.assertContains(response, 'data-sort-index="0"')
        self.assertContains(response, 'data-sort-index="5"')
        self.assertContains(response, 'data-table-page-size')
        self.assertContains(response, 'data-table-prev')
        self.assertContains(response, 'data-table-next')
        self.assertContains(response, 'Notation Guide')
        self.assertContains(response, 'CITY 1')
        self.assertContains(response, 'Winner by Area')
        self.assertContains(response, 'Export CSV')
        self.assertContains(response, 'Export PDF')

    def test_compare_page_shows_barangay_detail_choice_when_city_is_selected(self):
        response = self.client.get(
            "/compare/",
            {
                "candidate_a": self.candidate_a.id,
                "candidate_b": self.candidate_b.id,
                "region": "REGION A",
                "province": "PROVINCE 1",
                "municipality": "CITY 1",
            },
        )

        self.assertContains(response, 'name="comparison_level"')
        self.assertContains(response, 'Selected City Summary')
        self.assertContains(response, 'Breakdown per Barangay')

    def test_compare_csv_export(self):
        response = self.client.get(
            "/compare/",
            {
                "candidate_a": self.candidate_a.id,
                "candidate_b": self.candidate_b.id,
                "region": "REGION A",
                "province": "PROVINCE 1",
                "municipality": "CITY 1",
                "comparison_level": "barangay",
                "export": "csv",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertIn("text/csv", response["Content-Type"])
        self.assertIn("attachment;", response["Content-Disposition"])
        csv_text = response.content.decode("utf-8-sig")
        self.assertIn("Barangay", csv_text)
        self.assertIn("BARANGAY 1", csv_text)

    def test_compare_pdf_export(self):
        response = self.client.get(
            "/compare/",
            {
                "candidate_a": self.candidate_a.id,
                "candidate_b": self.candidate_b.id,
                "region": "REGION A",
                "province": "PROVINCE 1",
                "municipality": "CITY 1",
                "comparison_level": "barangay",
                "export": "pdf",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Content-Type"], "application/pdf")
        self.assertIn("attachment;", response["Content-Disposition"])
        self.assertTrue(response.content.startswith(b"%PDF"))

    def test_detail_candidate_switcher_redirects_with_filters(self):
        response = self.client.get(
            f"/senators/{self.candidate_a.id}/",
            {
                "region": "REGION A",
                "province": "PROVINCE 1",
                "municipality": "CITY 1",
                "inspect_candidate": self.candidate_b.id,
            },
        )

        self.assertEqual(response.status_code, 302)
        self.assertIn(f"/senators/{self.candidate_b.id}/", response["Location"])
        self.assertIn("region=REGION+A", response["Location"])
        self.assertIn("province=PROVINCE+1", response["Location"])
        self.assertIn("municipality=CITY+1", response["Location"])


class ImportCommandTests(TestCase):
    def test_parse_candidate_name(self):
        parsed = parse_candidate_name("12. DELA CRUZ, JUAN, JR. (PDP)")

        self.assertEqual(parsed["ballot_number"], 12)
        self.assertEqual(parsed["last_name"], "DELA CRUZ")
        self.assertEqual(parsed["first_name"], "JUAN")
        self.assertEqual(parsed["suffix"], "JR.")
        self.assertEqual(parsed["full_name"], "JUAN JR. DELA CRUZ")
        self.assertEqual(parsed["party_code"], "PDP")

    def test_import_command_creates_candidates_and_results(self):
        with tempfile.NamedTemporaryFile("w", newline="", suffix=".csv", delete=False) as handle:
            writer = csv.writer(handle)
            writer.writerow(
                [
                    "Year",
                    "Election_Type",
                    "Region",
                    "Province",
                    "Municipality",
                    "Barangay",
                    "Precinct_Code",
                    "Candidate_Name",
                    "Position",
                    "Party",
                    "Votes",
                    "Total_Voters",
                    "Total_Votes",
                    "Percentage",
                    "Contest_ID",
                    "Candidate_ID",
                    "Scraped_At",
                    "Source",
                ]
            )
            writer.writerow(
                [
                    2025,
                    "Senatorial",
                    "REGION A",
                    "PROVINCE 1",
                    "CITY 1",
                    "BARANGAY 1",
                    "P-001",
                    "1. ALPHA, ANA (P1)",
                    "Senator",
                    "Party One",
                    70,
                    100,
                    150,
                    46.67,
                    0,
                    101,
                    "8/21/2025 21:41",
                    "COMELEC_2025",
                ]
            )
            writer.writerow(
                [
                    2025,
                    "Senatorial",
                    "REGION A",
                    "PROVINCE 1",
                    "CITY 1",
                    "BARANGAY 1",
                    "P-001",
                    "2. BRAVO, BEN (P2)",
                    "Senator",
                    "Party Two",
                    80,
                    100,
                    150,
                    53.33,
                    0,
                    102,
                    "8/21/2025 21:41",
                    "COMELEC_2025",
                ]
            )
            temp_path = handle.name

        stdout = StringIO()
        try:
            call_command("import_lav_senatorial", temp_path, stdout=stdout)
        finally:
            os.unlink(temp_path)

        self.assertEqual(Candidate.objects.count(), 2)
        self.assertEqual(ElectionResult.objects.count(), 2)

        candidate = Candidate.objects.get(raw_name="1. ALPHA, ANA (P1)")
        result = ElectionResult.objects.get(candidate=candidate)

        self.assertEqual(candidate.full_name, "ANA ALPHA")
        self.assertEqual(candidate.party_name, "Party One")
        self.assertEqual(result.region, "REGION A")
        self.assertEqual(result.total_votes, 150)

    def test_import_command_supports_wide_precinct_format_with_region_filter(self):
        with tempfile.NamedTemporaryFile("w", newline="", suffix=".csv", delete=False, encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(
                [
                    "RegionProfileID",
                    "region",
                    "province",
                    "municipality",
                    "barangay",
                    "machineId",
                    "registeredVoters",
                    "actualVoters",
                    "validBallot",
                    "overVotes",
                    "underVotes",
                    "validVotes",
                    "obtainedVotes",
                    "1. ALPHA, ANA (P1)",
                    "2. BRAVO, BEN (P2)",
                ]
            )
            writer.writerow(
                [
                    1,
                    "NATIONAL CAPITAL REGION",
                    "NATIONAL CAPITAL REGION - FOURTH DISTRICT",
                    "CITY OF MAKATI",
                    "BEL-AIR",
                    "M-001",
                    100,
                    80,
                    80,
                    0,
                    0,
                    500,
                    150,
                    90,
                    60,
                ]
            )
            writer.writerow(
                [
                    2,
                    "REGION I",
                    "PANGASINAN",
                    "CALASIAO",
                    "NALSIAN",
                    "P-001",
                    100,
                    70,
                    70,
                    0,
                    0,
                    400,
                    110,
                    70,
                    40,
                ]
            )
            temp_path = handle.name

        try:
            call_command(
                "import_lav_senatorial",
                temp_path,
                "--region",
                "NATIONAL CAPITAL REGION",
            )
        finally:
            os.unlink(temp_path)

        self.assertEqual(Candidate.objects.count(), 2)
        self.assertEqual(ElectionResult.objects.count(), 10)

        municipality_rows = ElectionResult.objects.filter(location_level=ElectionResult.LEVEL_MUNICIPALITY).order_by(
            "candidate__ballot_number"
        )
        self.assertEqual(municipality_rows[0].region, "NATIONAL CAPITAL REGION")
        self.assertEqual(municipality_rows[0].municipality, "CITY OF MAKATI")
        self.assertEqual(municipality_rows[0].total_voters, 80)
        self.assertEqual(municipality_rows[0].total_votes, 500)
        self.assertEqual(municipality_rows[0].votes, 90)
        self.assertEqual(municipality_rows[1].votes, 60)
