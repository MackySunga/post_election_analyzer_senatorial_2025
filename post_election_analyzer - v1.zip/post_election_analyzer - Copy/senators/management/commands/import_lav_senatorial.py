import csv
import hashlib
import re
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from senators.models import Candidate, ElectionResult


def normalize(value: str) -> str:
    return (value or "").replace("\x00", "").strip()


def parse_candidate_name(raw_name: str) -> dict:
    cleaned = normalize(raw_name)

    ballot_match = re.match(r"^\s*(\d+)\.\s*", cleaned)
    ballot_number = int(ballot_match.group(1)) if ballot_match else 0
    cleaned = re.sub(r"^\s*\d+\.\s*", "", cleaned)

    party_code_match = re.search(r"\(([^()]*)\)\s*$", cleaned)
    party_code = party_code_match.group(1).strip() if party_code_match else ""
    if party_code_match:
        cleaned = cleaned[:party_code_match.start()].strip()

    parts = [part.strip() for part in cleaned.split(",")]
    last_name = parts[0] if parts else ""
    first_name = parts[1] if len(parts) >= 2 else ""
    suffix = ", ".join(parts[2:]).strip() if len(parts) > 2 else ""

    full_name = " ".join(piece for piece in [first_name, suffix, last_name] if piece).strip()
    if not full_name:
        full_name = cleaned

    return {
        "ballot_number": ballot_number,
        "last_name": last_name,
        "first_name": first_name,
        "suffix": suffix,
        "full_name": full_name,
        "party_code": party_code,
    }


def parse_scraped_at(value: str):
    text = normalize(value)
    if not text:
        return None

    iso_guess = parse_datetime(text)
    if iso_guess is not None:
        if timezone.is_naive(iso_guess):
            return timezone.make_aware(iso_guess, timezone.get_current_timezone())
        return iso_guess

    for fmt in ("%m/%d/%Y %H:%M", "%m/%d/%Y %H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            dt = timezone.datetime.strptime(text, fmt)
            return timezone.make_aware(dt, timezone.get_current_timezone())
        except ValueError:
            continue

    return None


def parse_int(value: str) -> int:
    return int(float(normalize(value) or 0))


def parse_float(value: str) -> float:
    return float(normalize(value) or 0)


LONG_REQUIRED_COLUMNS = {
    "Year",
    "Election_Type",
    "Region",
    "Province",
    "Municipality",
    "Barangay",
    "Precinct_Code",
    "Candidate_Name",
    "Position",
    "Party",
    "Votes",
    "Total_Voters",
    "Total_Votes",
    "Percentage",
    "Contest_ID",
    "Candidate_ID",
    "Scraped_At",
    "Source",
}

WIDE_REQUIRED_COLUMNS = {
    "RegionProfileID",
    "region",
    "province",
    "municipality",
    "barangay",
    "machineId",
    "registeredVoters",
    "actualVoters",
    "validBallot",
    "overVotes",
    "underVotes",
    "validVotes",
    "obtainedVotes",
}


def candidate_columns_from_headers(fieldnames):
    return [field for field in (fieldnames or []) if re.match(r"^\d+\.", field or "")]


class Command(BaseCommand):
    help = "Import senatorial election results from a tab-separated or comma-separated file."

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str, help="Path to the election results file")
        parser.add_argument("--clear", action="store_true", help="Delete existing records before importing")
        parser.add_argument(
            "--region",
            type=str,
            help="Optional region filter. Useful for importing only NCR from the wide precinct dataset.",
        )

    def _get_or_create_candidate(self, raw_name: str, party_name: str = "", position: str = "Senator", external_id: str = ""):
        parsed = parse_candidate_name(raw_name)
        candidate, was_created = Candidate.objects.get_or_create(
            raw_name=raw_name,
            defaults={
                "ballot_number": parsed["ballot_number"],
                "last_name": parsed["last_name"],
                "first_name": parsed["first_name"],
                "suffix": parsed["suffix"],
                "full_name": parsed["full_name"],
                "party_code": parsed["party_code"],
                "party_name": party_name or parsed["party_code"],
                "position": position or "Senator",
                "candidate_external_id": external_id,
            },
        )
        return candidate, was_created

    def _bulk_flush(self, buffer):
        if buffer:
            ElectionResult.objects.bulk_create(buffer, batch_size=5000)
            created = len(buffer)
            buffer.clear()
            return created
        return 0

    def _wide_location_scopes(self, row: dict):
        region = normalize(row["region"])
        province = normalize(row["province"])
        municipality = normalize(row["municipality"])
        barangay = normalize(row["barangay"])
        return [
            (ElectionResult.LEVEL_NATIONAL, "", "", "", ""),
            (ElectionResult.LEVEL_REGION, region, "", "", ""),
            (ElectionResult.LEVEL_PROVINCE, region, province, "", ""),
            (ElectionResult.LEVEL_MUNICIPALITY, region, province, municipality, ""),
            (ElectionResult.LEVEL_BARANGAY, region, province, municipality, barangay),
        ]

    def _location_code(self, scope_key: tuple[str, str, str, str, str]) -> str:
        digest = hashlib.sha1("||".join(scope_key).encode("utf-8")).hexdigest()
        return f"{scope_key[0]}:{digest}"

    def _import_long_format(self, reader, region_filter: str):
        created_candidates = 0
        created_results = 0
        candidate_cache = {}

        for row in reader:
            if normalize(row["Election_Type"]) != "Senatorial":
                continue
            if region_filter and normalize(row["Region"]) != region_filter:
                continue

            raw_name = normalize(row["Candidate_Name"])
            candidate = candidate_cache.get(raw_name)
            if candidate is None:
                candidate, was_created = self._get_or_create_candidate(
                    raw_name=raw_name,
                    party_name=normalize(row["Party"]),
                    position=normalize(row["Position"]),
                    external_id=normalize(row["Candidate_ID"]),
                )
                candidate_cache[raw_name] = candidate
                if was_created:
                    created_candidates += 1

            ElectionResult.objects.create(
                candidate=candidate,
                year=parse_int(row["Year"]),
                election_type=normalize(row["Election_Type"]),
                location_level=ElectionResult.LEVEL_PRECINCT,
                region=normalize(row["Region"]),
                province=normalize(row["Province"]),
                municipality=normalize(row["Municipality"]),
                barangay=normalize(row["Barangay"]),
                precinct_code=normalize(row["Precinct_Code"]),
                votes=parse_int(row["Votes"]),
                total_voters=parse_int(row["Total_Voters"]),
                total_votes=parse_int(row["Total_Votes"]),
                percentage=parse_float(row["Percentage"]),
                contest_id=normalize(row["Contest_ID"]),
                scraped_at=parse_scraped_at(row["Scraped_At"]),
                source=normalize(row["Source"]),
            )
            created_results += 1

        return created_candidates, created_results

    def _import_wide_format(self, file_path: Path, dialect, candidate_columns, region_filter: str, source_name: str):
        created_candidates = 0
        created_results = 0
        candidate_cache = {}

        for raw_name in candidate_columns:
            candidate, was_created = self._get_or_create_candidate(
                raw_name=normalize(raw_name),
                party_name=parse_candidate_name(raw_name)["party_code"],
                position="Senator",
                external_id=str(parse_candidate_name(raw_name)["ballot_number"]),
            )
            candidate_cache[raw_name] = candidate
            if was_created:
                created_candidates += 1

        turnout_rollups = {}
        with file_path.open("r", encoding="utf-8-sig", errors="replace", newline="") as handle:
            reader = csv.DictReader(handle, dialect=dialect)
            for row in reader:
                row_region = normalize(row["region"])
                if region_filter and row_region != region_filter:
                    continue

                total_voters = parse_int(row["actualVoters"])
                total_votes = parse_int(row["validVotes"])
                for scope_key in self._wide_location_scopes(row):
                    rollup = turnout_rollups.setdefault(
                        scope_key,
                        {"total_voters": 0, "total_votes": 0},
                    )
                    rollup["total_voters"] += total_voters
                    rollup["total_votes"] += total_votes

        for raw_name in candidate_columns:
            vote_rollups = {}
            with file_path.open("r", encoding="utf-8-sig", errors="replace", newline="") as handle:
                reader = csv.DictReader(handle, dialect=dialect)
                for row in reader:
                    row_region = normalize(row["region"])
                    if region_filter and row_region != region_filter:
                        continue

                    votes = parse_int(row.get(raw_name))
                    if votes <= 0:
                        continue

                    for scope_key in self._wide_location_scopes(row):
                        vote_rollups[scope_key] = vote_rollups.get(scope_key, 0) + votes

            buffer = []
            candidate = candidate_cache[raw_name]
            for scope_key, votes in vote_rollups.items():
                turnout = turnout_rollups[scope_key]
                level, region, province, municipality, barangay = scope_key
                total_votes = turnout["total_votes"]
                buffer.append(
                    ElectionResult(
                        candidate=candidate,
                        year=2025,
                        election_type="Senatorial",
                        location_level=level,
                        region=region,
                        province=province,
                        municipality=municipality,
                        barangay=barangay,
                        precinct_code=self._location_code(scope_key),
                        votes=votes,
                        total_voters=turnout["total_voters"],
                        total_votes=total_votes,
                        percentage=round((votes / total_votes) * 100, 4) if total_votes else 0.0,
                        contest_id="",
                        scraped_at=None,
                        source=source_name,
                    )
                )
                if len(buffer) >= 5000:
                    created_results += self._bulk_flush(buffer)
            created_results += self._bulk_flush(buffer)

        return created_candidates, created_results

    @transaction.atomic
    def handle(self, *args, **options):
        file_path = Path(options["file_path"])
        if not file_path.exists():
            raise CommandError(f"File not found: {file_path}")
        region_filter = normalize(options.get("region"))

        if options["clear"]:
            ElectionResult.objects.all().delete()
            Candidate.objects.all().delete()
            self.stdout.write(self.style.WARNING("Existing data cleared."))

        with file_path.open("r", encoding="utf-8-sig", errors="replace", newline="") as handle:
            sample = handle.read(2048)
            handle.seek(0)
            dialect = csv.Sniffer().sniff(sample, delimiters="\t,;")
            reader = csv.DictReader(handle, dialect=dialect)

            fieldnames = reader.fieldnames or []
            if LONG_REQUIRED_COLUMNS.issubset(fieldnames):
                created_candidates, created_results = self._import_long_format(reader, region_filter)
            else:
                candidate_columns = candidate_columns_from_headers(fieldnames)
                if not WIDE_REQUIRED_COLUMNS.issubset(fieldnames) or not candidate_columns:
                    missing = sorted(LONG_REQUIRED_COLUMNS.difference(fieldnames))
                    wide_missing = sorted(WIDE_REQUIRED_COLUMNS.difference(fieldnames))
                    raise CommandError(
                        "Unsupported file format. "
                        f"Long-format missing: {missing}. Wide-format missing: {wide_missing}."
                    )
                created_candidates, created_results = self._import_wide_format(
                    file_path,
                    dialect,
                    candidate_columns,
                    region_filter,
                    file_path.name,
                )

        self.stdout.write(self.style.SUCCESS(f"Created candidates: {created_candidates}"))
        self.stdout.write(self.style.SUCCESS(f"Created election results: {created_results}"))
