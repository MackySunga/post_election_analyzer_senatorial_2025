from django.contrib import admin

from .models import Candidate, ElectionResult


@admin.register(Candidate)
class CandidateAdmin(admin.ModelAdmin):
    list_display = ("ballot_number", "last_name", "first_name", "party_code", "party_name")
    search_fields = ("full_name", "last_name", "first_name", "party_name", "party_code")
    list_filter = ("party_name",)


@admin.register(ElectionResult)
class ElectionResultAdmin(admin.ModelAdmin):
    list_display = (
        "candidate",
        "region",
        "province",
        "municipality",
        "precinct_code",
        "votes",
        "total_voters",
    )
    search_fields = ("candidate__full_name", "region", "province", "municipality", "precinct_code")
    list_filter = ("region", "province", "municipality")
    list_select_related = ("candidate",)
