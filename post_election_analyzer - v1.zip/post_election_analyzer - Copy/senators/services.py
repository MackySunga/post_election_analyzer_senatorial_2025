from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional

from django.db.models import Max, Q, Sum

from .models import Candidate, ElectionResult

ALL_FILTER = "ALL"
SMALL_SCOPE_ROW_THRESHOLD = 5000
LEVEL_NATIONAL = ElectionResult.LEVEL_NATIONAL
LEVEL_REGION = ElectionResult.LEVEL_REGION
LEVEL_PROVINCE = ElectionResult.LEVEL_PROVINCE
LEVEL_MUNICIPALITY = ElectionResult.LEVEL_MUNICIPALITY
LEVEL_BARANGAY = ElectionResult.LEVEL_BARANGAY


@dataclass
class AggregatedRow:
    name: str
    province: str = ""
    scope_key: str = ""
    voters: int = 0
    candidate_votes: int = 0
    total_votes_all_candidates: int = 0

    @property
    def candidate_share_of_location_votes(self) -> float:
        if self.total_votes_all_candidates == 0:
            return 0.0
        return (self.candidate_votes / self.total_votes_all_candidates) * 100

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "province": self.province,
            "scope_key": self.scope_key or self.name,
            "voters": self.voters,
            "candidate_votes": self.candidate_votes,
            "total_votes_all_candidates": self.total_votes_all_candidates,
            "candidate_share_of_location_votes": round(self.candidate_share_of_location_votes, 2),
        }


def normalize_filter_value(value: Optional[str]) -> str:
    return (value or "").strip() or ALL_FILTER


def get_regions() -> List[str]:
    return list(
        ElectionResult.objects.filter(location_level=LEVEL_REGION).order_by("region")
        .values_list("region", flat=True)
        .distinct()
    )


def get_location_tree() -> dict:
    rows = (
        ElectionResult.objects.filter(location_level=LEVEL_MUNICIPALITY).order_by("region", "province", "municipality")
        .values("region", "province", "municipality")
        .distinct()
    )
    tree: dict[str, dict[str, list[str]]] = {}
    for row in rows:
        region = row["region"]
        province = row["province"]
        municipality = row["municipality"]
        tree.setdefault(region, {}).setdefault(province, [])
        if municipality not in tree[region][province]:
            tree[region][province].append(municipality)
    return tree


def _all_provinces(tree: dict, region: str) -> List[str]:
    if region != ALL_FILTER:
        return sorted(tree.get(region, {}).keys())

    provinces = set()
    for region_values in tree.values():
        provinces.update(region_values.keys())
    return sorted(provinces)


def _all_municipalities(tree: dict, region: str, province: str) -> List[str]:
    municipalities = set()
    if region != ALL_FILTER and province != ALL_FILTER:
        municipalities.update(tree.get(region, {}).get(province, []))
    elif region != ALL_FILTER:
        for province_values in tree.get(region, {}).values():
            municipalities.update(province_values)
    elif province != ALL_FILTER:
        for region_values in tree.values():
            municipalities.update(region_values.get(province, []))
    else:
        for region_values in tree.values():
            for province_values in region_values.values():
                municipalities.update(province_values)
    return sorted(municipalities)


def resolve_location_filters(
    region: Optional[str] = None,
    province: Optional[str] = None,
    municipality: Optional[str] = None,
) -> dict:
    tree = get_location_tree()
    regions = sorted(tree.keys())
    default_region = regions[0] if len(regions) == 1 else ALL_FILTER

    selected_region = normalize_filter_value(region)
    if selected_region == ALL_FILTER and default_region != ALL_FILTER:
        selected_region = default_region
    if selected_region != ALL_FILTER and selected_region not in regions:
        selected_region = default_region

    province_options = _all_provinces(tree, selected_region)
    selected_province = normalize_filter_value(province)
    if selected_province != ALL_FILTER and selected_province not in province_options:
        selected_province = ALL_FILTER

    municipality_options = _all_municipalities(tree, selected_region, selected_province)
    selected_municipality = normalize_filter_value(municipality)
    if selected_municipality != ALL_FILTER and selected_municipality not in municipality_options:
        selected_municipality = ALL_FILTER

    return {
        "location_tree": tree,
        "regions": regions,
        "province_options": province_options,
        "municipality_options": municipality_options,
        "selected_region": selected_region,
        "selected_province": selected_province,
        "selected_municipality": selected_municipality,
    }


def candidate_search_queryset(search: str = ""):
    qs = Candidate.objects.all()
    if search:
        qs = qs.filter(
            Q(full_name__icontains=search)
            | Q(last_name__icontains=search)
            | Q(first_name__icontains=search)
            | Q(party_name__icontains=search)
            | Q(party_code__icontains=search)
        )
    return qs


def filtered_results(
    level: Optional[str] = None,
    region: Optional[str] = None,
    province: Optional[str] = None,
    municipality: Optional[str] = None,
):
    qs = ElectionResult.objects.all()
    if level:
        qs = qs.filter(location_level=level)
    filters = {
        "region": normalize_filter_value(region),
        "province": normalize_filter_value(province),
        "municipality": normalize_filter_value(municipality),
    }
    for field_name, value in filters.items():
        if value != ALL_FILTER:
            qs = qs.filter(**{field_name: value})
    return qs


def _unique_precinct_rollups(records, field_name: Optional[str | list[str]] = None):
    grouping = ["precinct_code"]
    if field_name:
        if isinstance(field_name, str):
            grouping.insert(0, field_name)
        else:
            grouping = list(field_name) + grouping
    return records.order_by().values(*grouping).annotate(
        voters=Max("total_voters"),
        total_votes=Max("total_votes"),
    )


def _sum_precinct_metric(rows: Iterable[dict], metric: str) -> int:
    return sum((row.get(metric) or 0) for row in rows)


def _totals_from_records(records, candidate: Candidate) -> dict:
    precinct_rows = list(_unique_precinct_rollups(records))
    total_voters = _sum_precinct_metric(precinct_rows, "voters")
    total_votes_all_candidates = _sum_precinct_metric(precinct_rows, "total_votes")
    candidate_votes = records.filter(candidate=candidate).aggregate(total=Sum("votes"))["total"] or 0
    candidate_share = (
        (candidate_votes / total_votes_all_candidates) * 100
        if total_votes_all_candidates
        else 0.0
    )
    return {
        "total_voters": total_voters,
        "candidate_votes": candidate_votes,
        "total_votes_all_candidates": total_votes_all_candidates,
        "candidate_scope_share": round(candidate_share, 2),
    }


def _group_fields_for_location(field_name: str) -> List[str]:
    if field_name == "municipality":
        return ["province", "municipality"]
    return [field_name]


def aggregate_by_location(records, candidate_id: int, field_name: str) -> List[dict]:
    group_fields = _group_fields_for_location(field_name)
    grouped: Dict[tuple[str, ...], AggregatedRow] = defaultdict(lambda: AggregatedRow(name=""))

    for precinct_row in _unique_precinct_rollups(records, group_fields):
        location_name = precinct_row.get(field_name) or "UNSPECIFIED"
        province_name = precinct_row.get("province") or ""
        location_key = tuple((precinct_row.get(group_field) or "UNSPECIFIED") for group_field in group_fields)
        grouped_row = grouped[location_key]
        grouped_row.name = location_name
        grouped_row.province = province_name
        grouped_row.scope_key = " || ".join(location_key)
        grouped_row.voters += precinct_row.get("voters") or 0
        grouped_row.total_votes_all_candidates += precinct_row.get("total_votes") or 0

    candidate_votes_by_location = (
        records.filter(candidate_id=candidate_id)
        .order_by()
        .values(*group_fields)
        .annotate(candidate_votes=Sum("votes"))
    )
    for row in candidate_votes_by_location:
        location_name = row.get(field_name) or "UNSPECIFIED"
        province_name = row.get("province") or ""
        location_key = tuple((row.get(group_field) or "UNSPECIFIED") for group_field in group_fields)
        grouped[location_key].name = location_name
        grouped[location_key].province = province_name
        grouped[location_key].scope_key = " || ".join(location_key)
        grouped[location_key].candidate_votes = row.get("candidate_votes") or 0

    return [grouped[key].to_dict() for key in sorted(grouped.keys())]


def _with_scope_shares(rows: List[dict], total_voters: int, candidate_votes: int) -> List[dict]:
    output = []
    for row in rows:
        output.append(
            {
                **row,
                "voter_share_of_scope": round((row["voters"] / total_voters) * 100, 2)
                if total_voters
                else 0.0,
                "candidate_vote_share_of_scope": round((row["candidate_votes"] / candidate_votes) * 100, 2)
                if candidate_votes
                else 0.0,
            }
        )
    return output


def build_breakdown_rows(records, candidate: Candidate, field_name: str) -> List[dict]:
    totals = _totals_from_records(records, candidate)
    rows = aggregate_by_location(records, candidate.id, field_name)
    return _with_scope_shares(rows, totals["total_voters"], totals["candidate_votes"])


def _python_rollup(records, candidate: Candidate, field_name: str) -> tuple[dict, List[dict]]:
    grouped: Dict[str, AggregatedRow] = defaultdict(lambda: AggregatedRow(name=""))
    scope_seen = set()
    location_seen = set()
    total_voters = 0
    total_votes_all_candidates = 0
    candidate_votes = 0

    for row in (
        records.order_by()
        .values("candidate_id", "precinct_code", "votes", "total_voters", "total_votes", field_name)
        .iterator(chunk_size=2000)
    ):
        location_name = row.get(field_name) or "UNSPECIFIED"
        grouped_row = grouped[location_name]
        grouped_row.name = location_name

        scope_key = row["precinct_code"]
        if scope_key not in scope_seen:
            scope_seen.add(scope_key)
            total_voters += row.get("total_voters") or 0
            total_votes_all_candidates += row.get("total_votes") or 0

        location_key = (location_name, row["precinct_code"])
        if location_key not in location_seen:
            location_seen.add(location_key)
            grouped_row.voters += row.get("total_voters") or 0
            grouped_row.total_votes_all_candidates += row.get("total_votes") or 0

        if row["candidate_id"] == candidate.id:
            vote_count = row.get("votes") or 0
            candidate_votes += vote_count
            grouped_row.candidate_votes += vote_count

    totals = {
        "total_voters": total_voters,
        "candidate_votes": candidate_votes,
        "total_votes_all_candidates": total_votes_all_candidates,
        "candidate_scope_share": round((candidate_votes / total_votes_all_candidates) * 100, 2)
        if total_votes_all_candidates
        else 0.0,
    }
    rows = [grouped[name].to_dict() for name in sorted(grouped.keys())]
    return totals, _with_scope_shares(rows, total_voters, candidate_votes)


def _python_compare_rollup(
    records,
    candidate_a: Candidate,
    candidate_b: Candidate,
    field_name: str,
) -> List[dict]:
    group_fields = _group_fields_for_location(field_name)
    value_fields = list(
        dict.fromkeys(["candidate_id", "precinct_code", "votes", "total_votes", "province", *group_fields])
    )
    grouped = {}
    location_seen = set()

    for row in (
        records.order_by()
        .values(*value_fields)
        .iterator(chunk_size=2000)
    ):
        location_key = tuple((row.get(group_field) or "UNSPECIFIED") for group_field in group_fields)
        display_name = row.get(field_name) or "UNSPECIFIED"
        province_name = row.get("province") or ""
        bucket = grouped.setdefault(
            location_key,
            {
                "name": display_name,
                "province": province_name,
                "scope_key": " || ".join(location_key),
                "candidate_a_votes": 0,
                "candidate_b_votes": 0,
                "total_votes_all_candidates": 0,
            },
        )

        totals_key = location_key + (row["precinct_code"],)
        if totals_key not in location_seen:
            location_seen.add(totals_key)
            bucket["total_votes_all_candidates"] += row.get("total_votes") or 0

        vote_count = row.get("votes") or 0
        if row["candidate_id"] == candidate_a.id:
            bucket["candidate_a_votes"] += vote_count
        elif row["candidate_id"] == candidate_b.id:
            bucket["candidate_b_votes"] += vote_count

    merged_rows = []
    for location_key in sorted(grouped.keys()):
        bucket = grouped[location_key]
        total_votes = bucket["total_votes_all_candidates"]
        votes_a = bucket["candidate_a_votes"]
        votes_b = bucket["candidate_b_votes"]
        merged_rows.append(
            {
                "name": bucket["name"],
                "province": bucket["province"],
                "scope_key": bucket["scope_key"],
                "candidate_a_votes": votes_a,
                "candidate_b_votes": votes_b,
                "vote_gap": votes_a - votes_b,
                "candidate_a_share": round((votes_a / total_votes) * 100, 2) if total_votes else 0.0,
                "candidate_b_share": round((votes_b / total_votes) * 100, 2) if total_votes else 0.0,
            }
        )

    merged_rows.sort(
        key=lambda item: max(item["candidate_a_votes"], item["candidate_b_votes"]),
        reverse=True,
    )
    return merged_rows


def _scope_level(
    region: Optional[str] = None,
    province: Optional[str] = None,
    municipality: Optional[str] = None,
) -> str:
    if normalize_filter_value(municipality) != ALL_FILTER:
        return LEVEL_MUNICIPALITY
    if normalize_filter_value(province) != ALL_FILTER:
        return LEVEL_PROVINCE
    if normalize_filter_value(region) != ALL_FILTER:
        return LEVEL_REGION
    return LEVEL_NATIONAL


def compute_candidate_dashboard(
    candidate: Candidate,
    region: Optional[str] = None,
    province: Optional[str] = None,
    municipality: Optional[str] = None,
) -> dict:
    scope_records = filtered_results(_scope_level(region, province, municipality), region, province, municipality)
    province_records = filtered_results(LEVEL_PROVINCE, region)
    municipality_records = filtered_results(LEVEL_MUNICIPALITY, region, province)

    scope_totals = _totals_from_records(scope_records, candidate)
    province_rows = build_breakdown_rows(province_records, candidate, "province")
    municipality_rows = build_breakdown_rows(municipality_records, candidate, "municipality")

    total_candidate_votes_in_region = sum(row["candidate_votes"] for row in province_rows) or 1
    top_3_provinces = []
    for row in sorted(province_rows, key=lambda item: item["candidate_votes"], reverse=True)[:3]:
        top_3_provinces.append(
            {
                **row,
                "percent_of_candidate_votes_in_selected_region": round(
                    (row["candidate_votes"] / total_candidate_votes_in_region) * 100, 2
                ),
            }
        )

    return {
        "selected_region": normalize_filter_value(region),
        "selected_province": normalize_filter_value(province),
        "selected_municipality": normalize_filter_value(municipality),
        **scope_totals,
        "province_turnout_rows": sorted(province_rows, key=lambda item: item["voters"], reverse=True),
        "municipality_turnout_rows": sorted(municipality_rows, key=lambda item: item["voters"], reverse=True),
        "province_vote_rows": sorted(province_rows, key=lambda item: item["candidate_votes"], reverse=True),
        "municipality_vote_rows": sorted(municipality_rows, key=lambda item: item["candidate_votes"], reverse=True),
        "top_3_provinces": top_3_provinces,
    }


def compute_barangay_dashboard(
    candidate: Candidate,
    region: Optional[str] = None,
    province: Optional[str] = None,
    municipality: Optional[str] = None,
) -> dict:
    selected_municipality = normalize_filter_value(municipality)
    if selected_municipality == ALL_FILTER:
        return {
            "selected_region": normalize_filter_value(region),
            "selected_province": normalize_filter_value(province),
            "selected_municipality": selected_municipality,
            "total_voters": 0,
            "candidate_votes": 0,
            "total_votes_all_candidates": 0,
            "candidate_scope_share": 0.0,
            "barangay_rows": [],
        }

    records = filtered_results(LEVEL_BARANGAY, region, province, municipality)
    totals, barangay_rows = _python_rollup(records, candidate, "barangay")

    return {
        "selected_region": normalize_filter_value(region),
        "selected_province": normalize_filter_value(province),
        "selected_municipality": selected_municipality,
        **totals,
        "barangay_rows": sorted(barangay_rows, key=lambda item: item["candidate_votes"], reverse=True),
    }


def _records_for_compare_level(
    region: Optional[str],
    province: Optional[str],
    municipality: Optional[str],
    comparison_level: Optional[str] = None,
) -> tuple[str, str, str, str]:
    if normalize_filter_value(municipality) != ALL_FILTER:
        if (comparison_level or "").strip().lower() == "barangay":
            return "barangay", "Barangay", LEVEL_BARANGAY, "barangay"
        return "municipality", "Selected City / Municipality", LEVEL_MUNICIPALITY, "summary"
    if normalize_filter_value(province) != ALL_FILTER:
        return "municipality", "City", LEVEL_MUNICIPALITY, "auto"
    return "province", "Province / District", LEVEL_PROVINCE, "auto"


def build_compare_dashboard(
    candidate_a: Candidate,
    candidate_b: Candidate,
    region: Optional[str] = None,
    province: Optional[str] = None,
    municipality: Optional[str] = None,
    comparison_level: Optional[str] = None,
) -> dict:
    scope_records = filtered_results(_scope_level(region, province, municipality), region, province, municipality)
    candidate_a_totals = _totals_from_records(scope_records, candidate_a)
    candidate_b_totals = _totals_from_records(scope_records, candidate_b)

    comparison_field, comparison_label, comparison_record_level, comparison_mode = _records_for_compare_level(
        region,
        province,
        municipality,
        comparison_level,
    )
    comparison_records = filtered_results(comparison_record_level, region, province, municipality)

    merged_rows = _python_compare_rollup(comparison_records, candidate_a, candidate_b, comparison_field)

    return {
        "selected_region": normalize_filter_value(region),
        "selected_province": normalize_filter_value(province),
        "selected_municipality": normalize_filter_value(municipality),
        "candidate_a_totals": candidate_a_totals,
        "candidate_b_totals": candidate_b_totals,
        "comparison_field": comparison_field,
        "comparison_label": comparison_label,
        "comparison_mode": comparison_mode,
        "comparison_rows": merged_rows,
    }


def _records_for_heatmap_level(
    level: str,
    region: Optional[str] = None,
    province: Optional[str] = None,
    municipality: Optional[str] = None,
):
    if level == "province":
        return filtered_results(LEVEL_PROVINCE, region)
    if level == "municipality":
        return filtered_results(LEVEL_MUNICIPALITY, region, province)
    return filtered_results(LEVEL_BARANGAY, region, province, municipality)


def build_heat_tiles(
    candidate: Candidate,
    region: Optional[str] = None,
    province: Optional[str] = None,
    municipality: Optional[str] = None,
    level: str = "province",
) -> List[dict]:
    records = _records_for_heatmap_level(level, region, province, municipality)
    rows = sorted(
        aggregate_by_location(records, candidate.id, level),
        key=lambda item: item["candidate_votes"],
        reverse=True,
    )
    max_votes = max((row["candidate_votes"] for row in rows), default=1)

    output = []
    for row in rows:
        intensity = round((row["candidate_votes"] / max_votes) * 100, 2) if max_votes else 0
        output.append(
            {
                "label": row["name"],
                "votes": row["candidate_votes"],
                "share": row["candidate_share_of_location_votes"],
                "intensity": intensity,
            }
        )
    return output
