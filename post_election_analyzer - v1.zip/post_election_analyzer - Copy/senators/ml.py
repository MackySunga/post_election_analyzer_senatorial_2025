from __future__ import annotations

import os
from collections import Counter
from typing import Optional

os.environ.setdefault("LOKY_MAX_CPU_COUNT", "1")

try:
    import numpy as np
    from sklearn.cluster import KMeans
    from sklearn.ensemble import IsolationForest
    from sklearn.neighbors import LocalOutlierFactor, NearestNeighbors
    from sklearn.preprocessing import StandardScaler
except ImportError:  # pragma: no cover - handled at runtime for missing optional deps
    np = None
    KMeans = None
    IsolationForest = None
    LocalOutlierFactor = None
    NearestNeighbors = None
    StandardScaler = None

from .models import Candidate
from .services import ALL_FILTER, compute_barangay_dashboard, normalize_filter_value


def _analysis_rows(candidate: Candidate, summary: dict, region: str, province: str, municipality: str) -> tuple[list[dict], str]:
    if municipality != ALL_FILTER:
        barangay_summary = compute_barangay_dashboard(candidate, region, province, municipality)
        rows = []
        for row in barangay_summary["barangay_rows"]:
            rows.append({**row, "province": province, "municipality": municipality})
        return rows, "Barangay"

    municipality_rows = list(summary.get("municipality_vote_rows", []))
    if province != ALL_FILTER and municipality_rows:
        return municipality_rows, "City / Municipality"
    if region != ALL_FILTER and municipality_rows:
        return municipality_rows, "City / Municipality"
    return list(summary.get("province_vote_rows", [])), "Province / District"


def _score_to_percentiles(values) -> list[float]:
    if np is None or not len(values):
        return []
    order = np.argsort(values)
    output = np.zeros(len(values), dtype=float)
    denominator = max(1, len(values) - 1)
    for rank, index in enumerate(order):
        output[index] = (rank / denominator) * 100
    return output.tolist()


def _cluster_count(row_count: int) -> int:
    if row_count >= 36:
        return 4
    if row_count >= 12:
        return 3
    return 2


def _cluster_label(center: list[float], medians: dict[str, float]) -> str:
    turnout_high = center[0] >= medians["turnout"]
    share_high = center[1] >= medians["share"]
    scope_high = center[2] >= medians["scope"]

    if share_high and turnout_high:
        return "High-turnout stronghold"
    if share_high and not turnout_high:
        return "Low-turnout stronghold"
    if not share_high and turnout_high:
        return "High-turnout competitive"
    if scope_high:
        return "Major vote contributor"
    return "Lower-intensity weak cluster"


def _anomaly_note(row: dict, medians: dict[str, float]) -> str:
    if row["turnout_rate"] >= medians["turnout"] and row["candidate_share"] <= medians["share"]:
        return "High turnout but muted candidate share."
    if row["turnout_rate"] <= medians["turnout"] and row["candidate_share"] >= medians["share"]:
        return "Low turnout but unusually strong candidate share."
    if row["scope_share"] >= medians["scope"]:
        return "Large contribution to the candidate total for this scope."
    return "Feature profile sits far from the current scope norm."


def _classify_area(row: dict, thresholds: dict[str, float]) -> str:
    if row["anomaly_score"] >= thresholds["anomaly"]:
        return "Anomaly Watch"
    if row["stronghold_score"] >= thresholds["stronghold"] and row["candidate_share"] >= thresholds["share_high"]:
        return "Stronghold"
    if row["stronghold_score"] >= thresholds["hotspot"] or (
        row["candidate_share"] >= thresholds["share_high"] and row["scope_share"] >= thresholds["scope_mid"]
    ):
        return "Hotspot"
    if row["candidate_share"] <= thresholds["share_low"] and row["turnout_rate"] <= thresholds["turnout_low"]:
        return "Coldspot"
    if row["turnout_rate"] <= thresholds["turnout_low"]:
        return "Low-turnout"
    return "Competitive"


def build_candidate_ml_insights(
    candidate: Candidate,
    summary: dict,
    region: Optional[str] = None,
    province: Optional[str] = None,
    municipality: Optional[str] = None,
    reference_area: str = "",
) -> dict:
    if np is None or StandardScaler is None:
        return {
            "available": False,
            "message": "ML dependencies are not installed. Install scikit-learn to enable this tab.",
            "summary_cards": [],
            "available_areas": [],
            "anomaly_rows": [],
            "cluster_profiles": [],
            "stronghold_rows": [],
            "similar_rows": [],
            "classification_rows": [],
            "reference_area": "",
            "level_label": "",
        }

    selected_region = normalize_filter_value(region)
    selected_province = normalize_filter_value(province)
    selected_municipality = normalize_filter_value(municipality)
    base_rows, level_label = _analysis_rows(
        candidate,
        summary,
        selected_region,
        selected_province,
        selected_municipality,
    )

    if len(base_rows) < 3:
        return {
            "available": False,
            "message": "Select a broader scope so the model has at least three areas to compare.",
            "summary_cards": [],
            "available_areas": [row["name"] for row in base_rows],
            "anomaly_rows": [],
            "cluster_profiles": [],
            "stronghold_rows": [],
            "similar_rows": [],
            "classification_rows": [],
            "reference_area": "",
            "level_label": level_label,
        }

    enriched_rows = []
    for row in base_rows:
        voters = row.get("voters") or 0
        valid_votes = row.get("total_votes_all_candidates") or 0
        candidate_votes = row.get("candidate_votes") or 0
        turnout_rate = (valid_votes / voters) * 100 if voters else 0.0
        vote_density = (candidate_votes / voters) * 100 if voters else 0.0
        enriched_rows.append(
            {
                **row,
                "turnout_rate": round(turnout_rate, 2),
                "candidate_share": round(row.get("candidate_share_of_location_votes", 0.0), 2),
                "scope_share": round(row.get("candidate_vote_share_of_scope", 0.0), 2),
                "vote_density": round(vote_density, 2),
                "province": row.get("province") or selected_province,
                "municipality": row.get("municipality") or selected_municipality,
            }
        )

    feature_matrix = np.array(
        [
            [
                row["turnout_rate"],
                row["candidate_share"],
                row["scope_share"],
                row["vote_density"],
            ]
            for row in enriched_rows
        ],
        dtype=float,
    )

    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(feature_matrix)

    contamination = min(0.15, max(0.05, 3 / len(enriched_rows)))
    isolation = IsolationForest(random_state=42, contamination=contamination)
    isolation.fit(scaled_features)
    anomaly_raw = -isolation.score_samples(scaled_features)
    if len(enriched_rows) >= 6:
        neighbors = min(20, len(enriched_rows) - 1)
        lof = LocalOutlierFactor(n_neighbors=neighbors, contamination=contamination)
        lof.fit_predict(scaled_features)
        lof_raw = -lof.negative_outlier_factor_
        anomaly_raw = (anomaly_raw + lof_raw) / 2
    anomaly_scores = _score_to_percentiles(anomaly_raw)

    stronghold_raw = (scaled_features[:, 1] * 0.55) + (scaled_features[:, 2] * 0.3) + (scaled_features[:, 0] * 0.15)
    stronghold_scores = _score_to_percentiles(stronghold_raw)

    cluster_count = min(_cluster_count(len(enriched_rows)), len(enriched_rows))
    cluster_model = KMeans(n_clusters=cluster_count, random_state=42, n_init=10)
    cluster_ids = cluster_model.fit_predict(scaled_features)
    cluster_centers = scaler.inverse_transform(cluster_model.cluster_centers_)

    turnout_rates = np.array([row["turnout_rate"] for row in enriched_rows], dtype=float)
    candidate_shares = np.array([row["candidate_share"] for row in enriched_rows], dtype=float)
    scope_shares = np.array([row["scope_share"] for row in enriched_rows], dtype=float)
    medians = {
        "turnout": float(np.median(turnout_rates)),
        "share": float(np.median(candidate_shares)),
        "scope": float(np.median(scope_shares)),
    }
    thresholds = {
        "anomaly": float(np.percentile(anomaly_scores, 85)),
        "stronghold": float(np.percentile(stronghold_scores, 75)),
        "hotspot": float(np.percentile(stronghold_scores, 55)),
        "share_high": float(np.percentile(candidate_shares, 70)),
        "share_low": float(np.percentile(candidate_shares, 35)),
        "scope_mid": medians["scope"],
        "turnout_low": float(np.percentile(turnout_rates, 35)),
    }

    cluster_labels = {
        cluster_index: _cluster_label(cluster_centers[cluster_index].tolist(), medians)
        for cluster_index in range(cluster_count)
    }

    for index, row in enumerate(enriched_rows):
        row["anomaly_score"] = round(anomaly_scores[index], 2)
        row["stronghold_score"] = round(stronghold_scores[index], 2)
        row["cluster_id"] = int(cluster_ids[index])
        row["cluster_label"] = cluster_labels[int(cluster_ids[index])]
        row["classification"] = _classify_area(row, thresholds)
        row["anomaly_note"] = _anomaly_note(row, medians)

    cluster_profiles = []
    for cluster_index in range(cluster_count):
        members = [row for row in enriched_rows if row["cluster_id"] == cluster_index]
        members_sorted = sorted(members, key=lambda row: row["stronghold_score"], reverse=True)
        cluster_profiles.append(
            {
                "cluster_label": cluster_labels[cluster_index],
                "area_count": len(members),
                "avg_turnout_rate": round(sum(row["turnout_rate"] for row in members) / len(members), 2),
                "avg_candidate_share": round(sum(row["candidate_share"] for row in members) / len(members), 2),
                "avg_scope_share": round(sum(row["scope_share"] for row in members) / len(members), 2),
                "examples": ", ".join(row["name"] for row in members_sorted[:3]),
            }
        )
    cluster_profiles.sort(key=lambda row: (row["avg_candidate_share"], row["area_count"]), reverse=True)

    anomaly_rows = sorted(enriched_rows, key=lambda row: row["anomaly_score"], reverse=True)[:10]
    stronghold_rows = sorted(enriched_rows, key=lambda row: row["stronghold_score"], reverse=True)[:10]

    available_area_names = [row["name"] for row in enriched_rows]
    selected_reference = reference_area if reference_area in available_area_names else stronghold_rows[0]["name"]
    reference_index = next(index for index, row in enumerate(enriched_rows) if row["name"] == selected_reference)

    neighbor_count = min(6, len(enriched_rows))
    neighbor_model = NearestNeighbors(n_neighbors=neighbor_count)
    neighbor_model.fit(scaled_features)
    distances, indices = neighbor_model.kneighbors(scaled_features[reference_index : reference_index + 1])
    distance_values = distances[0][1:]
    max_distance = max(distance_values) if len(distance_values) else 1.0
    max_distance = max(max_distance, 1e-6)
    similar_rows = []
    for distance, index in zip(distances[0][1:], indices[0][1:]):
        match = enriched_rows[int(index)]
        similarity_score = 100 - ((distance / max_distance) * 100)
        similar_rows.append(
            {
                "name": match["name"],
                "province": match["province"],
                "classification": match["classification"],
                "similarity_score": round(similarity_score, 2),
                "candidate_share": match["candidate_share"],
                "turnout_rate": match["turnout_rate"],
            }
        )

    classification_rows = sorted(
        enriched_rows,
        key=lambda row: (
            row["classification"] != "Stronghold",
            row["classification"] != "Hotspot",
            -row["stronghold_score"],
            -row["anomaly_score"],
        ),
    )
    classification_counts = Counter(row["classification"] for row in enriched_rows)

    return {
        "available": True,
        "message": "",
        "level_label": level_label,
        "reference_area": selected_reference,
        "available_areas": available_area_names,
        "summary_cards": [
            {
                "label": "Areas Analyzed",
                "value": len(enriched_rows),
                "detail": level_label,
            },
            {
                "label": "Anomaly Watchlist",
                "value": classification_counts.get("Anomaly Watch", 0),
                "detail": "Isolation Forest + LOF",
            },
            {
                "label": "Stronghold / Hotspot",
                "value": classification_counts.get("Stronghold", 0) + classification_counts.get("Hotspot", 0),
                "detail": "High-share locations",
            },
            {
                "label": "Clusters",
                "value": cluster_count,
                "detail": "Voting behavior groups",
            },
        ],
        "anomaly_rows": anomaly_rows,
        "cluster_profiles": cluster_profiles,
        "stronghold_rows": stronghold_rows,
        "similar_rows": similar_rows,
        "classification_rows": classification_rows[:15],
        "classification_counts": dict(classification_counts),
    }
