from django.urls import path

from . import views

app_name = "senators"

urlpatterns = [
    path("", views.home, name="home"),
    path("senators/", views.senator_list, name="senator_list"),
    path("compare/", views.compare_senators, name="compare_senators"),
    path("senators/<int:candidate_id>/", views.senator_detail, name="senator_detail"),
    path("senators/<int:candidate_id>/barangays/", views.barangay_drilldown, name="barangay_drilldown"),
]
