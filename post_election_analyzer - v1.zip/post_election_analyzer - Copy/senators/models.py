from django.db import models


class Candidate(models.Model):
    ballot_number = models.PositiveIntegerField(default=0)
    raw_name = models.CharField(max_length=255, unique=True)
    last_name = models.CharField(max_length=120, blank=True)
    first_name = models.CharField(max_length=120, blank=True)
    suffix = models.CharField(max_length=50, blank=True)
    full_name = models.CharField(max_length=255)
    party_code = models.CharField(max_length=30, blank=True)
    party_name = models.CharField(max_length=255, blank=True)
    position = models.CharField(max_length=120, default="Senator")
    candidate_external_id = models.CharField(max_length=50, blank=True)

    class Meta:
        ordering = ["last_name", "first_name", "ballot_number"]

    def __str__(self):
        return self.full_name


class ElectionResult(models.Model):
    LEVEL_NATIONAL = "national"
    LEVEL_REGION = "region"
    LEVEL_PROVINCE = "province"
    LEVEL_MUNICIPALITY = "municipality"
    LEVEL_BARANGAY = "barangay"
    LEVEL_PRECINCT = "precinct"
    LEVEL_CHOICES = [
        (LEVEL_NATIONAL, "National"),
        (LEVEL_REGION, "Region"),
        (LEVEL_PROVINCE, "Province / District"),
        (LEVEL_MUNICIPALITY, "Municipality / City"),
        (LEVEL_BARANGAY, "Barangay"),
        (LEVEL_PRECINCT, "Precinct"),
    ]

    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE, related_name="results")
    year = models.PositiveIntegerField(default=2025)
    election_type = models.CharField(max_length=100, default="Senatorial")
    location_level = models.CharField(max_length=20, choices=LEVEL_CHOICES, default=LEVEL_PRECINCT)
    region = models.CharField(max_length=150)
    province = models.CharField(max_length=150)
    municipality = models.CharField(max_length=150)
    barangay = models.CharField(max_length=150, blank=True)
    precinct_code = models.CharField(max_length=255)
    votes = models.PositiveIntegerField(default=0)
    total_voters = models.PositiveIntegerField(default=0)
    total_votes = models.PositiveIntegerField(default=0)
    percentage = models.FloatField(default=0.0)
    contest_id = models.CharField(max_length=50, blank=True)
    scraped_at = models.DateTimeField(null=True, blank=True)
    source = models.CharField(max_length=100, blank=True)

    class Meta:
        ordering = [
            "location_level",
            "candidate__ballot_number",
            "region",
            "province",
            "municipality",
            "barangay",
            "precinct_code",
        ]
        indexes = [
            models.Index(
                fields=["candidate", "location_level", "region", "province", "municipality"],
                name="sen_el_cand_scope",
            ),
            models.Index(
                fields=["location_level", "region", "province", "municipality"],
                name="sen_el_lvl_scope",
            ),
            models.Index(fields=["location_level", "barangay"], name="sen_el_lvl_bgy"),
            models.Index(fields=["location_level", "precinct_code"], name="sen_el_lvl_prec"),
        ]

    def __str__(self):
        return f"{self.candidate.full_name} | {self.region} | {self.province} | {self.municipality} | {self.votes}"
